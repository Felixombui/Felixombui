<?php
include 'config.php';
$uid = $_GET['uid'];
$userqry = mysqli_query( $config, "UPDATE system_users SET `status`='Active' WHERE id='$uid'" );
header( 'location:signin.php' );
?>