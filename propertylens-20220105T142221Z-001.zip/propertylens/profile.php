<?php
include 'headers.php';
?>
<p>
<style>
.headertable {
    border-collapse: collapse;
    border-bottom: 1px cyan solid;
    border-right: 1px cyan solid;
    border-left: 1px cyan solid;
    box-shadow: 1px 1px cyan;
}

</style>
<table  align = 'center' width = '80%' class = 'headertable'><tr class = 'profileheader'><td>
<table><tr><td><div class = 'linkbutton'><a href = 'profile.php'>Basic info</a></div>  <div class = 'linkbutton'><a href = 'moreinfo.php'>More info</a></div> <div class = 'linkbutton'><a href = 'myadverts.php'>My Ads</a></div> <div class = 'linkbutton'><a href = 'myposts.php'>My Posts</a></div></td></tr></table>
</td></tr>
<tr><td>
<table><tr><td><img src = 'images/user.png' width = '100' height = '100' align = 'left'></td><td> Names: <?php echo $_SESSION['fullnames'] ?><br>Email: <?php echo $_SESSION['emailaddress'] ?><br>
Phone: <?php echo $_SESSION['phonenumber'] ?><br>
<a href = 'updateprofile.php'><img src = 'images/edit.png' width = '20' height = '20' align = 'left'>Edit Details</a></td></tr></table>
</td></tr>
</table>
</p>
<style>
<?php echo include 'styles.css' ?>
</style>