<?php
include 'headers.php';
$id = $_GET['eid'];
$userid = $_SESSION['userid'];
$enquiries = mysqli_query( $config, "SELECT * FROM enquiries WHERE id='$id'" );
$enqrow = mysqli_fetch_assoc( $enquiries );
$quserid = $enqrow['userid'];
$comms = mysqli_query( $config, "SELECT * FROM enq_comments WHERE anqid='$id'" );
$comments = mysqli_num_rows( $comms );
if ( $_SESSION['username'] ) {
    $addcomment = '<form method="POST"><textarea cols="50" rows="1" name="comment_text" placeholder="Add your comment..."></textarea><input type="submit" name="comment" value="Comment" class="searchbutton" style="float:right;"></form>';
} else {
    $addcomment = '<div style="background-color:grey; font-size:12; padding:5px; color:white;"><i>You must be signed in to comment!</i></div>';
}
if ( $_POST['comment'] ) {
    $comment_text = addslashes( $_POST['comment_text'] );
    $commentowner = addslashes( $_SESSION['fullnames'] );
    $commentdate = date( 'd/m/Y' );
    if ( empty( $comment_text ) ) {
        //do nothing
        echo 'error';
    } else {
        mysqli_query( $config, "INSERT INTO enq_comments(anqid,userid,commentowner,comment,commentdate) VALUES('$id','$userid','$commentowner','$comment_text','$commentdate' )" );
        header( 'location:enquiries.php?eid='.$id );
    }

}
?>
<p>

<table width = '80%' align = 'center'>
<tr><td>
<div style = 'float: left; width:50%'>
<table width = '100%'><tr>
<td><img src = 'images/user.png' width = '30' height = '30' align = 'left'><b>
<?php echo "<a href='userprofile.php?userid=".$quserid."'>". $enqrow['usernames'].'</a>';
echo '</b><br><i>'. $enqrow['enquirydate'].'<i>';
?></td>
</tr>
<tr><td><?php echo $enqrow['enquiry'] ?></td></tr>
<tr><td><div style = 'color: blue; font-size:11;'>Comments: <?php echo $comments ?></div></td></tr>
<tr><td><img src = 'images/user.png' width = '20' height = '20' align = 'left'><?php echo $addcomment ?></td></tr>
<tr><td>

<?php
while( $comrow = mysqli_fetch_assoc( $comms ) ) {
    $cuserid = $comrow['userid'];
    echo "<table width = '90%' align = 'right' style = 'background-color: cyan; margin:5px; border-radius:5px;'><tr><td><img src = 'images/user.png' width = '20' height = '20' align = 'left'><b> <a href='userprofile.php?userid=".$cuserid."'>".$comrow['commentowner']."</a></b><br>
    ".$comrow['comment']."<div style='color:grey;
    font-size:12;
    '>".$comrow['commentdate'].'</div></td></tr></table>';
}
?>

</td></tr>
</table>
<?php

?>
</div>

</td></tr>
</table>
</p>
<style>
<?php echo include 'styles.css' ?>
</style>