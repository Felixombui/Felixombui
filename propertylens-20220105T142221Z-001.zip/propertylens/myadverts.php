<?php
include 'headers.php';
$username = $_SESSION['username'];
$myads = mysqli_query( $config, "SELECT * FROM adverts WHERE advertowner='$username'" );

function custom_echo( $x, $length )
 {
    if ( strlen( $x ) <= $length )
 {
        echo $x;
    } else {
        $y = substr( $x, 0, $length ) . '...';
        echo $y;
    }
}
?>
<p>
<style>
.headertable {
    border-collapse: collapse;
    border-bottom: 1px cyan solid;
    border-right: 1px cyan solid;
    border-left: 1px cyan solid;
    box-shadow: 1px 1px cyan;
}

</style>
<table  align = 'center' width = '80%' class = 'headertable'><tr class = 'profileheader'><td>
<table><tr><td><div class = 'linkbutton'><a href = 'profile.php'>Basic info</a></div>  <div class = 'linkbutton'><a href = 'moreinfo.php'>More info</a></div> <div class = 'linkbutton'><a href = 'myadverts.php'>My Ads</a></div> <div class = 'linkbutton'><a href = 'myposts.php'>My Posts</a></div></td></tr></table>
</td></tr>
<tr><td>
<div align = 'right'><a href = 'newad.php'><button class = 'searchbutton'>New Advert</button></a></div>
<?php
if ( mysqli_num_rows( $myads )>0 ) {
    echo '<table width="100%" style="border-collapse:collapse;" class="adstable">';
    echo '<tr><th>Image</th><th>Description</th><th>Unit Cost</th><th>County</th><th>Locality</th><th>Status</th><th>Edit</th></tr>';
    while( $adsrow = mysqli_fetch_assoc( $myads ) ) {
        $id = $adsrow['id'];
        $image = $adsrow['image'];
        $description = $adsrow['description'];
        $unitcost = $adsrow['unitcost'];
        $county = $adsrow['county'];
        $locality = $adsrow['locality'];
        $status = $adsrow['status'];
        echo '<tr><td><img src="'.$image.'" width="70" height="50" align="left" padding="5"></td><td width="20%">';
        custom_echo( $description, 50 );
        echo '</td><td>'.number_format( $unitcost, 0 ).'</td><td>'.$county.'</td><td>'.$locality.'</td><td>'.$status.'</td><td align="center"><a href="editad.php?id='.$id.'"><img src="images/edit.png" width="20" height="20"></a></td></tr>';
    }
    echo '</table';
} else {
    echo 'You have not posted any ads';
}

?>
</td></tr>
</table>
</p>
<style>
<?php echo include 'styles.css' ?>
</style>