<?php
include 'headers.php';
$mychats = mysqli_query( $config, 'SELECT * FROM inbox' );

?>
<table width = '80%' align = 'center' style = 'background-color:cyan;'><tr><th>From</th><th>Message</th>

</tr></table>
<style>
<?php
echo include 'styles.css'
?>
</style>