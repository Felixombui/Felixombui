<?php
include 'headers.php';
//new cURL function
function get_web_page( $myurl )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );

    $ch      = curl_init( $myurl );
    curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    return $header;
}
//end of function
if ( isset( $_POST['register'] ) ) {
    $fullnames = addslashes( $_POST['fullnames'] );
    $emailaddress = addslashes( $_POST['emailaddress'] );
    $phonenumber = addslashes( $_POST['phonenumber'] );
    $username = addslashes( $_POST['username'] );
    $password = addslashes( $_POST['password'] );
    $cpassword = addslashes( $_POST['cpassword'] );
    $userclass = addslashes( $_POST['userclass'] );
    $score = 0;
    if ( empty( $fullnames ) ) {
        $nameErr = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must enter full names!</div>';
    } else {
        $score = $score+1;
    }
    if ( empty( $emailaddress ) ) {
        $emailErr = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must enter email address!</div>';
    } else {
        $score = $score+1;
    }
    if ( empty( $phonenumber ) ) {
        $phoneErr = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must enter phone number!</div>';
    } else {
        $score = $score+1;
    }
    if ( empty( $username ) ) {
        $usernameErr = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must create a username!</div>';
    } else {
        $score = $score+1;
    }
    if ( empty( $password ) ) {
        $passwordErr = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must create a password!</div>';
    } else {
        $score = $score+1;
    }
    if ( $score>4 ) {
        //check whether username exists
        $usrqry = mysqli_query( $config, "SELECT * FROM system_users WHERE username='$username'" );
        if ( mysqli_num_rows( $usrqry )>0 ) {
            $usernameErr = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">Username already taken!</div>';
        } else {
            if ( $password == $cpassword ) {
                //save user
                $password = md5( $password, false );
                mysqli_query( $config, "INSERT INTO system_users(names,emailaddress,phonenumber,username,`password`,user_class) VALUES('$fullnames','$emailaddress','$phonenumber','$username','$password','$userclass')" );
                $details = mysqli_query( $config, "SELECT * FROM system_users WHERE username='$username'" );
                $detailrow = mysqli_fetch_assoc( $details );
                $uid = $detailrow['id'];
                //create email to be sent to user
                //$mailheader = 'From: info@macrasystems.com';
                $link = 'https://propertylens.co.ke/confirm.php?uid='.$uid;
                $mailSubject=urlencode('Welcome to Property Lens');
                $message = 'Dear '.$fullnames.'\n Registration with Kenya Property Market was successful. Welcome on board.\n Click on '.$link.' to validate your account.';
                $maillink='https://propertylens.co.ke/mailer.php?emailaddress='.$emailaddress.'&mailNames='.$fullnames.'&subject=Welcome+to Property+Lens&mailMessage='.$message;
                get_web_page($maillink);
                $chars = strlen( $phonenumber );
                if ( $chars<11 ) {
                    $stripzero = ltrim( $phonenumber, '0' );
                    $phonenumber = '254'.$stripzero;
                }
                $msg = urlencode( 'Dear '.$fullnames.', Welcome to Kenya Property Market. Your registration was successful. Please check your email '.$emailaddress.' for an activation link.' );
                $url='http://sms.macrasystems.com/sendsms/index.php?username=Mankan&senderid=SMARTLINK&phonenumber='.$phonenumber.'&message='.$msg;
                get_web_page($url);
                $success = '<img src="images/success.png" width="20" height="20"> Registration was successful. Please check your email for a confirmation link.';
            } else {
                $cpasswordErr = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">Passwords do not match!</div>';
            }
        }
    }
}
?>
<p>
<div class = 'formdiv' align = 'center'>
<form method = 'post'>
Please enter your details below
<table>
<tr><td>Full Names *</td><td><input type = 'text' name = 'fullnames'></td><td><?php echo $nameErr ?></td></tr>
<tr><td>Email Address *</td><td><input type = 'email' name = 'emailaddress'></td><td><?php echo $emailErr ?></td></tr>
<tr><td>Phone Number *</td><td><input type = 'text' name = 'phonenumber'></td><td><?php echo $phoneErr ?></td></tr>
<tr><td>Create Username *</td><td><input type = 'text' name = 'username'></td><td><?php echo $usernameErr ?></td></tr>
<tr><td>Create password *</td><td><input type = 'password' name = 'password'></td><td><?php echo $passwordErr ?></td></tr>
<tr><td>Confirm password *</td><td><input type = 'password' name = 'cpassword'></td><td><?php echo $cpasswordErr ?></td></tr>
<tr><td>Who are you?</td><td>
<select name = 'userclass'>
<option>Select option</option>
<option>Seller</option>
<option>Buyer</option>
</select>
</td></tr>
<tr><td></td><td><input type = 'submit' name = 'register' value = 'Register Free'></td><td></td></tr>
</table>
<div align = 'left'>
<img src = 'images/info.png' width = '18' height = '18' align = 'left'>By clicking 'Register Free' you agree to our <a href = 'termsandconditions.html' target = '_blank'>terms and conditions</a></div>
</form>
<?php echo $success ?>
</div></p>
<style>
<?php echo include 'styles.css' ?>
</style>