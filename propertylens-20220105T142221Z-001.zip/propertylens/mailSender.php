<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


$mail = new PHPMailer(true);
$emailaddress=$_GET['emailaddress'];
$mailNames=$_GET['mailNames'];
$subject=$_GET['subject'];
$mailMessage=$_GET['mailMessage'];

try{
    //server settings
    $mail->SMTPDebug = 2;  //enable verbose debug output
    $mail->IsSMTP();
    $mail->Host='lon105.truehost.cloud';
    $mail->SMTPAuth=true;   //enables SMTP authentication
    $mail->Username='info@propertylens.co.ke';
    $mail->Password='propertylens2021';
    $mail->SMTPSecure='tls';
    $mail->Port=587;
    
    //recipients
    $mail->setFrom('info@propertylens.co.ke','Info');
    //$mail->addAddress('raphmachoka@gmail.com','Raphael Machoka');
    $mail->addAddress($emailaddress,$mailNames);
    $mail->addReplyTo('info@propertylens.co.ke','Info');

    
    //content
    $mail->isHTML(true);
    $mail->Subject=$subject;
    $mail->Body=$mailMessage;
    $mail->AltBody=$mailMessage;
    
    $mail->send();
    echo 'Message has been sent';
}catch (Exception $e){
    echo 'Message could not be sent. Mailer Error: {$mail->ErrorInfo}';
}
?>