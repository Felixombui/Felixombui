<?php
include 'headers.php';
?>
<p>
<style>
.headertable {
    border-collapse: collapse;
    border-bottom: 1px cyan solid;
    border-right: 1px cyan solid;
    border-left: 1px cyan solid;
    box-shadow: 1px 1px cyan;
}
</style>
<table class = 'headertable' width = '80%' align = 'center'><tr><td>
<table width = '50%' align = 'center'><tr><td>
<form method = 'post'>Select Type
<select name = 'type' style = 'width: 200px;'>
<option>Land</option>
<option>House</option>
<option>Rentals</option>
<option>Apartment</option>
<option>School</option>
<option>Hotel</option>
<option>Home</option>
</select>
<input type = 'submit' name = 'next' value = 'Next'>
</form>
</td></tr></table>
</td></tr></table>
<style>
<?php echo include 'styles.css' ?>
</style>