<?php
include 'headers.php';
if ( isset( $_POST['login'] ) ) {
    $username = addslashes( $_POST['username'] );
    $password = addslashes( $_POST['password'] );
    if ( empty( $username ) ) {
        $error = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">Login failed! Please enter your username.</div>';
    } else {
        if ( empty( $password ) ) {
            $error = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">Login failed! Please enter your password.</div>';
        } else {
            $password = md5( $password, false );
            $loginqry = mysqli_query( $config, "SELECT * FROM system_users  WHERE username='$username' AND password='$password'" );
            if ( mysqli_num_rows( $loginqry )>0 ) {
                //check if account is approved
                $loginrow = mysqli_fetch_assoc( $loginqry );
                $fullnames = $loginrow['names'];
                $emailaddress = $loginrow['emailaddress'];
                $phonenumber = $loginrow['phonenumber'];
                $status = $loginrow['status'];
                $userid = $loginrow['id'];
                if ( $status == 'Pending' ) {
                    $error = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">Your account activation is pending. Please go to your email and click on the activation link.</div>';
                } else {
                    session_start();
                    $_SESSION['userid'] = $userid;
                    $_SESSION['username'] = $username;
                    $_SESSION['fullnames'] = $fullnames;
                    $_SESSION['emailaddress'] = $emailaddress;
                    $_SESSION['phonenumber'] = $phonenumber;
                    header( 'location:index.php' );
                }
            } else {
                $error = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">Login failed! Please try again.</div>';
            }
        }
    }
}
?>
<p>
<div class = 'formdiv' align = 'center'>
Please enter your username and password
<form method = 'post'>
<table>
<tr><td>Username:</td><td><input type = 'text' name = 'username'></td></tr>
<tr><td>Password</td><td><input type = 'password' name = 'password'></td></tr>
<tr><td></td><td align = 'right'><input type = 'submit' name = 'login' value = 'Login'</td></tr>
</table>
<a href = 'recover.php'>I forgot my password!</a></form>
<table><tr><td><?php echo $error ?></td></tr></table>
</div></p>

<style>
<?php echo include 'styles.css' ?>
</style>
