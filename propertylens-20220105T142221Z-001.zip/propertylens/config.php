<?php
$server = 'localhost';
$db_user = 'macrasystems';
$db_pass = 'kasarani';
$dbbase = 'proper11_kpm';
$config = mysqli_connect( $server, $db_user, $db_pass, $dbbase ) or die( 'Error! Connection failed.' );
?>