<?php
include '../config.php';
$id = $_GET['id'];
$sq = $_GET['sq'];
if ( mysqli_query( $config, "DELETE FROM contacts WHERE id='$id'" ) ) {
    header( 'location:contacts.php?sql='.$sq );
}
?>