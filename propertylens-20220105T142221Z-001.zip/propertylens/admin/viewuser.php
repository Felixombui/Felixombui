<?php
include 'headers.php';
if ( !$_SESSION['admin'] ) {
    header( 'location:admin_login.php' );
}

function custom_echo( $x, $length )
 {
    if ( strlen( $x ) <= $length )
 {
        echo $x;
    } else {
        $y = substr( $x, 0, $length ) . '...';
        echo $y;
    }
}
$sq = $_GET['sq'];
$id = $_GET['id'];
$query = mysqli_query( $config, "SELECT * FROM system_users  WHERE user_class='$sq'" );
$qrow = mysqli_fetch_assoc( $query );
$names = $qrow['names'];
$emailaddress = $qrow['emailaddress'];
$phonenumber = $qrow['phonenumber'];
$username = $qrow['username'];
$usertype = $qrow['user_class'];
$regdate = $qrow['regdate'];
$status = $qrow['status'];
$adsqry = mysqli_query( $config, "SELECT * FROM adverts WHERE advertowner='$username'" );
$inq_qry = mysqli_query( $config, "SELECT * FROM enquiries WHERE usernames='$names'" );
?>
<style>
<?php echo include '../styles.css' ?>
</style>
<table width = '99%' style = 'height: 100%;'><tr><td>
<div style = 'float: left; width:20%; background-color:cyan; height:100%; border-right:1px solid orange'>
<table width = '100%' class = 'adminmenu'>
<tr><td><a href = 'index.php'><img src = '../images/cpanel.png' width = '20' height = '20' align = 'left'>Main Panel</a></td></tr>
<tr><td><a href = 'adverts.php'><img src = '../images/ads.png' width = '20' height = '20' align = 'left'>Adverts</a></td></tr>
<tr><td><a href = 'inquiries.php'><img src = '../images/inquiry.png' width = '20' height = '20' align = 'left'>Inquiries</a></td></tr>
<tr><td><a href = 'contacts.php'><img src = '../images/contacts.png' width = '20' height = '20' align = 'left'>Contacts</a></td></tr>
<tr><td><a href = 'users.php?sq=Buyer'><img src = '../images/buyers.png' width = '20' height = '20' align = 'left'>Buyers</a></td></tr>
<tr><td><a href = 'users.php?sq=Seller'><img src = '../images/sellers.png' width = '20' height = '20' align = 'left'>Sellers</a></td></tr>
<tr><td><a href = 'users.php?sq=Agent'><img src = '../images/agents.png' width = '20' height = '20' align = 'left'>Agents</a></td></tr>
<tr><td><a href = 'users.php?sq=Landlord'><img src = '../images/landlords.png' width = '20' height = '20' align = 'left'>Landlords</a></td></tr>
<tr><td><a href = 'emails.php'><img src = '../images/emails.png' width = '20' height = '20' align = 'left'>Emails sent</a></td></tr>
<tr><td><a href = 'sms.php'><img src = '../images/sms.png' width = '20' height = '20' align = 'left'>Messages Sent</a></td></tr>
</table>
</div>
<div style = 'float:right; width:78%;'>
<table width = '100%'><tr><td>
<form method = 'post'>
<?php echo '<a href="users.php?sq='.$sq.'"> << Back </a> '?>
</form>
<hr color = 'orange'>
<table width = '30%' style = 'border-collapse: collapse; float:left; border:1px solid pink; margin:5px;'><tr><th>Member Details</th></tr>
<tr><td>
<?php
echo 'Names: '.$names.'<br>
Email: '.$emailaddress.'<br
Phone: '.$phonenumber, '<br>
Username: '.$username.'<br>
User Type: '.$usertype.'<br>
Member From: '.$regdate.'<br
Status: '.$status;
?>
</td></tr>
</table>
<table width = '68%' style = 'margin-left:5px; border-collapse:collapse; border:1px solid pink; float:right;'><tr><th>Adverts by <?php echo $names ?></th></tr>
<tr><td>
<table width = '100%' style = 'border-collapse: collapse;'>
<?php
while( $adsrow = mysqli_fetch_assoc( $adsqry ) ) {
    $adid = $adsrow['id'];
    $adtitle = $adsrow['title'];
    $adsdescription = $adsrow['description'];
    $adtype = $adsrow['propertytype'];
    $adstatus = $adsrow['status'];
    echo '<tr style = "border:1px solid cyan;"><td>'.$adid.'</td><td>'.$adtitle.'</td><td>';
    custom_echo( $adsdescription, 30 );
    echo '</td><td>'.$adtype.'</td><td>'.$adstatus.'</td></tr>';
}
?>

</table>
</td></tr>
</table>
<table width = '30%' style = 'border-collapse: collapse; border:1px solid pink; float:left;'><tr><th>Inquiries by <?php echo $names ?></th></tr>
<tr><td>
<table width = '100%' style = 'border-collapse:collapse;'>
<tr style = 'font-weight: bold;'><td>#</td><td>Title</td><td>Inquiry</td></tr>
<?php
while( $inqrow = mysqli_fetch_assoc( $inq_qry ) ) {
    $inqid = $inqrow['id'];
    $inqtitle = $inqrow['title'];
    $inqdescription = $inqrow['enquiry'];
    echo '<tr style = "border:1px solid cyan;"><td>'.$inqid.'</td><td>'.$inqtitle.'</td><td>';
    custom_echo( $inqdescription, 20 );
    echo '</td></tr>';
}
?>
</table>
</td></tr>
</table>
</td></tr></table>
</div>
</td></tr></table>