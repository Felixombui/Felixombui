<?php
include '../config.php';
$id = $_GET['id'];
$sq = $_GET['sq'];
if ( mysqli_query( $config, "UPDATE enquiries SET `status`='Approved' WHERE id='$id'" ) ) {
    header( 'location:inquiries.php?sq='.$sq );
}

?>