<?php
session_start();
include '../config.php';
echo '<title>Admin Panel</title>';
if ( !$_SESSION['admin'] ) {
    $admindetails = 'Please Login below';
    //header( 'location:admin_login.php' );
} else {
    $admindetails = 'Welcome '. $_SESSION['admin'].' { <a href="logout.php" style="color:white;">Logout</a> }';
}
echo "<div class = 'headers' style = 'padding:10px; width:98%; Float:center;'><h1><img src = '../images/cpanel.png' width = '60' height = '40' align = 'left'>Admin Panel</h1></div>";
echo "<div style = 'background-color: blue; padding:5px; width:99%; margin-top:5px; color:white;'>".$admindetails.'</div>'
?>

