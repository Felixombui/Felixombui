<?php
include 'headers.php';
if ( !$_SESSION['admin'] ) {
    header( 'location:admin_login.php' );
}
$adsqry = mysqli_query( $config, 'SELECT * FROM adverts' );
$ads = mysqli_num_rows( $adsqry );
$pendingadsqry = mysqli_query( $config, "SELECT * FROM adverts WHERE `status`='Pending'" );
$pendingads = mysqli_num_rows( $pendingadsqry );
$inquiryqry = mysqli_query( $config, 'SELECT * FROM enquiries' );
$inquiries = mysqli_num_rows( $inquiryqry );
$pendinginquiryqry = mysqli_query( $config, "SELECT * FROM enquiries Where status='Pending'" );
$pendinginquiries = mysqli_num_rows( $pendinginquiryqry );
$contactsqry = mysqli_query( $config, 'SELECT * FROM contacts' );
$contacts = mysqli_num_rows( $contactsqry );
$newcontactsqry = mysqli_query( $config, "SELECT * FROM contacts WHERE `status`='New'" );
$newcontacts = mysqli_num_rows( $newcontactsqry );
$userqry = mysqli_query( $config, 'SELECT * FROM system_users' );
$buyers = 0;
$sellers = 0;
$agents = 0;
$landlords = 0;
while( $user = mysqli_fetch_assoc( $userqry ) ) {
    $usertype = $user['user_class'];
    if ( $usertype == 'Seller' ) {
        $sellers = $sellers+1;
    } else {
        if ( $usertype == 'Buyer' ) {
            $buyers = $buyers+1;
        } else {
            if ( $usertype == 'Agent' ) {
                $agents = $agents+1;
            } else {
                if ( $usertype == 'Landlord' ) {
                    $landlords = $landlords+1;
                }
            }
        }
    }
}
$smsqry = mysqli_query( $config, 'SELECT * FROM sms' );
$sms = mysqli_num_rows( $smsqry );
$emailsqry = mysqli_query( $config, 'SELECT * FROM emails' );
$emails = mysqli_num_rows( $emailsqry );
?>
<style>
<?php echo include '../styles.css' ?>
</style>
<table width = '99%' style = 'height: 100%;'><tr><td>
<div style = 'float: left; width:20%; background-color:cyan; height:100%; border-right:1px solid orange'>
<table width = '100%' class = 'adminmenu'>
<tr><td><a href = 'index.php'><img src = '../images/cpanel.png' width = '20' height = '20' align = 'left'>Main Panel</a></td></tr>
<tr><td><a href = 'adverts.php'><img src = '../images/ads.png' width = '20' height = '20' align = 'left'>Adverts</a></td></tr>
<tr><td><a href = 'inquiries.php'><img src = '../images/inquiry.png' width = '20' height = '20' align = 'left'>Inquiries</a></td></tr>
<tr><td><a href = 'contacts.php'><img src = '../images/contacts.png' width = '20' height = '20' align = 'left'>Contacts</a></td></tr>
<tr><td><a href = 'users.php?sq=Buyer'><img src = '../images/buyers.png' width = '20' height = '20' align = 'left'>Buyers</a></td></tr>
<tr><td><a href = 'users.php?sq=Seller'><img src = '../images/sellers.png' width = '20' height = '20' align = 'left'>Sellers</a></td></tr>
<tr><td><a href = 'users.php?sq=Agent'><img src = '../images/agents.png' width = '20' height = '20' align = 'left'>Agents</a></td></tr>
<tr><td><a href = 'users.php?sq=Landlord'><img src = '../images/landlords.png' width = '20' height = '20' align = 'left'>Landlords</a></td></tr>
<tr><td><a href = 'emails.php'><img src = '../images/emails.png' width = '20' height = '20' align = 'left'>Emails sent</a></td></tr>
<tr><td><a href = 'sms.php'><img src = '../images/sms.png' width = '20' height = '20' align = 'left'>Messages Sent</a></td></tr>
<tr><td><a href = 'admin_users.php'><img src = '../images/user.png' width = '20' height = '20' align = 'left'>Admin Users</a></td></tr>
</table>
</div>
<div style = 'float:right; width:78%;'>
<div class = 'panelitem' align = 'center'><img src = '../images/ads.png' width = '30' height = '30'><br><a href = 'adverts.php?sq=All'>Adverts: <?php echo $ads ?></a><br><a href = 'adverts.php?sq=New'>New: <?php echo $pendingads ?></a></div>
<div class = 'panelitem' align = 'center'><img src = '../images/inquiry.png' width = '30' height = '30'><br><a href = 'inquiries.php?sq=all'>Inquiries: <?php echo $inquiries ?></a><br><a href = 'inquiries.php?sq=new'>New: <?php echo $pendinginquiries ?></a></div>
<div class = 'panelitem' align = 'center'><img src = '../images/contacts.png' width = '30' height = '30'><br><a href = 'contacts.php?sq=all'>Contacts Made: <?php echo $contacts ?></a><br><a href = 'contacts.php?sq=New'>New: <?php echo $newcontacts ?></a></div>
<div class = 'panelitem' align = 'center'><img src = '../images/buyers.png' width = '30' height = '30'><br><a href = 'users.php?sq=Buyer'>Buyers: <?php echo $buyers ?></a></div>
<div class = 'panelitem' align = 'center'><img src = '../images/sellers.png' width = '30' height = '30'><br><a href = 'users.php?sq=Seller'>Sellers: <?php echo $sellers ?></a></div>
<div class = 'panelitem' align = 'center'><img src = '../images/agents.png' width = '30' height = '30'><br><a href = 'users.php?sq=Agent'>Agents: <?php echo $agents ?></a></div>
<div class = 'panelitem' align = 'center'><img src = '../images/landlords.png' width = '30' height = '30'><br><a href = 'users.php?sq=Landlord'>Landlords: <?php echo $landlords ?></a></div>
<div class = 'panelitem' align = 'center'><img src = '../images/emails.png' width = '30' height = '30'><br><a href = 'emails.php'>Sent Emails: <?php echo $emails ?></a></div>
<div class = 'panelitem' align = 'center'><img src = '../images/sms.png' width = '30' height = '30'><br><a href = 'sms.php'>Sent Messages: <?php echo $sms ?></a></div>

</div>
</td></tr></table>