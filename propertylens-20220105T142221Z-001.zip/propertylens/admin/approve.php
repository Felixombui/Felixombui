<?php
include '../config.php';
$id = $_GET['id'];
$sq = $_GET['sq'];
$qry = mysqli_query( $config, "SELECT * FROM adverts WHERE id='$id'" );
$row = mysqli_fetch_assoc( $qry );
$userid = $row['userid'];
$usrqry = mysqli_query( $config, "SELECT * FROM system_users WHERE id='$userid'" );
$usrRow = mysqli_fetch_assoc( $usrqry );
$userphone = $usrRow['phonenumber'];
$username = $usrRow['username'];

if ( mysqli_query( $config, "UPDATE adverts SET `status`='Approved' WHERE id='$id'" ) ) {
    $chars = strlen( $userphone );
    if ( $chars<11 ) {
        $newphone = ltrim( $userphone, '0' );
        $phonenumber = '254'.$newphone;
    }
    $sms = urlencode( 'Dear '.$username.', Your advert id '.$id.' has been approved. It is now visible on Kenya Property website.' );
    $url = 'https://sms.macrasystems.com/sendsms/index.php?username=Mankan&senderid=SMARTLINK&phonenumber='.$phonenumber.'&message='.$sms;
    file_get_contents( $url );
    header( 'location:adverts.php?sq='.$sq );
}

?>