<?php
include 'headers.php';
if ( !$_SESSION['admin'] ) {
    header( 'location:admin_login.php' );
}
$sq = $_GET['sq'];
$query = mysqli_query( $config, "SELECT * FROM system_users  WHERE user_class='$sq'" );
if ( isset( $_POST['go'] ) ) {
    if ( $_POST['show'] == 'Buyers' ) {
        $sq = 'Buyer';
    } else {
        if ( $_POST['show'] == 'Sellers' ) {
            $sq = 'Seller';
        } else {
            if ( $_POST['show'] == 'Agents' ) {
                $sq = 'Agent';
            } else {
                if ( $_POST['show'] == 'Landlords' ) {
                    $sq = 'Landlord';
                }
            }

        }
    }
    header( 'location:users.php?sq='.$sq );
}
?>
<style>
<?php echo include '../styles.css' ?>
</style>
<table width = '99%' style = 'height: 100%;'><tr><td>
<div style = 'float: left; width:20%; background-color:cyan; height:100%; border-right:1px solid orange'>
<table width = '100%' class = 'adminmenu'>
<tr><td><a href = 'index.php'><img src = '../images/cpanel.png' width = '20' height = '20' align = 'left'>Main Panel</a></td></tr>
<tr><td><a href = 'adverts.php'><img src = '../images/ads.png' width = '20' height = '20' align = 'left'>Adverts</a></td></tr>
<tr><td><a href = 'inquiries.php'><img src = '../images/inquiry.png' width = '20' height = '20' align = 'left'>Inquiries</a></td></tr>
<tr><td><a href = 'contacts.php'><img src = '../images/contacts.png' width = '20' height = '20' align = 'left'>Contacts</a></td></tr>
<tr><td><a href = 'users.php?sq=Buyer'><img src = '../images/buyers.png' width = '20' height = '20' align = 'left'>Buyers</a></td></tr>
<tr><td><a href = 'users.php?sq=Seller'><img src = '../images/sellers.png' width = '20' height = '20' align = 'left'>Sellers</a></td></tr>
<tr><td><a href = 'users.php?sq=Agent'><img src = '../images/agents.png' width = '20' height = '20' align = 'left'>Agents</a></td></tr>
<tr><td><a href = 'users.php?sq=Landlord'><img src = '../images/landlords.png' width = '20' height = '20' align = 'left'>Landlords</a></td></tr>
<tr><td><a href = 'emails.php'><img src = '../images/emails.png' width = '20' height = '20' align = 'left'>Emails sent</a></td></tr>
<tr><td><a href = 'sms.php'><img src = '../images/sms.png' width = '20' height = '20' align = 'left'>Messages Sent</a></td></tr>
</table>
</div>
<div style = 'float:right; width:78%;'>
<table width = '100%'><tr><td>
<form method = 'post'>Show: <select name = 'show'>
<option>--Select option--</option>
<option selected><?php echo $sq.'s' ?></option>
<option>All</option>
<option>Buyers</option>
<option>Sellers</option>
<option>Agents</option>
<option>Landlords</option>
</select>
<input type = 'submit' name = 'go' value = 'Search'></form>
<hr color = 'orange'>
<table width = '100%' style = 'border-collapse: collapse;'><tr style = 'text-align: left;'><th>#</th><th>Names</th><th>Email</th><th>Phone</th><th>Username<th>Status
</th><th></th></tr>
<?php
while( @$adsrow = mysqli_fetch_assoc( $query ) ) {
    $id = $adsrow['id'];
    $names = $adsrow['names'];
    $phonenumber = $adsrow['phonenumber'];
    $emailaddress = $adsrow['emailaddress'];
    $username = $adsrow['username'];
    //$date = $adsrow['date_time'];
    $status = $adsrow['status'];
    echo '<tr><td>'.$id.'</td><td>'.$names.'</td><td>'.$emailaddress.'</td><td>'.$phonenumber.'</td><td>'.$username.'</td><td>'.$status.'</td><td><a href="viewuser.php?id='.$id.'&sq='.$sq.'"><img src="../images/view.png" width="20" height="20"></a></td></tr>';
}
?>
</table>
</td></tr></table>
</div>
</td></tr></table>