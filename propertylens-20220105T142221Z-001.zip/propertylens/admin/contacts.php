<?php
include 'headers.php';
if ( !$_SESSION['admin'] ) {
    header( 'location:admin_login.php' );
}
$sq = $_GET['sq'];
if ( $sq == 'All' ) {
    $inq_qry = mysqli_query( $config, 'SELECT * FROM contacts ORDER BY id DESC' );
} else {
    if ( $sq == 'New' ) {
        $inq_qry = mysqli_query( $config, "SELECT * FROM contacts WHERE status='New' ORDER BY id DESC" );
    }
}
if ( isset( $_POST['go'] ) ) {
    header( 'location:contacts.php?sq='.$_POST['show'] );
}
?>
<style>
<?php echo include '../styles.css' ?>
</style>
<table width = '99%' style = 'height: 100%;'><tr><td>
<div style = 'float: left; width:20%; background-color:cyan; height:100%; border-right:1px solid orange'>
<table width = '100%' class = 'adminmenu'>
<tr><td><a href = 'index.php'><img src = '../images/cpanel.png' width = '20' height = '20' align = 'left'>Main Panel</a></td></tr>
<tr><td><a href = 'adverts.php'><img src = '../images/ads.png' width = '20' height = '20' align = 'left'>Adverts</a></td></tr>
<tr><td><a href = 'inquiries.php'><img src = '../images/inquiry.png' width = '20' height = '20' align = 'left'>Inquiries</a></td></tr>
<tr><td><a href = 'contacts.php'><img src = '../images/contacts.png' width = '20' height = '20' align = 'left'>Contacts</a></td></tr>
<tr><td><a href = 'users.php?sq=Buyer'><img src = '../images/buyers.png' width = '20' height = '20' align = 'left'>Buyers</a></td></tr>
<tr><td><a href = 'users.php?sq=Seller'><img src = '../images/sellers.png' width = '20' height = '20' align = 'left'>Sellers</a></td></tr>
<tr><td><a href = 'users.php?sq=Agent'><img src = '../images/agents.png' width = '20' height = '20' align = 'left'>Agents</a></td></tr>
<tr><td><a href = 'users.php?sq=Landlord'><img src = '../images/landlords.png' width = '20' height = '20' align = 'left'>Landlords</a></td></tr>
<tr><td><a href = 'emails.php'><img src = '../images/emails.png' width = '20' height = '20' align = 'left'>Emails sent</a></td></tr>
<tr><td><a href = 'sms.php'><img src = '../images/sms.png' width = '20' height = '20' align = 'left'>Messages Sent</a></td></tr>
</table>
</div>
<div style = 'float:right; width:78%;'>
<table width = '100%'><tr><td>
<form method = 'post'>Show: <select name = 'show'>
<option>--Select option--</option>
<option>All</option>
<option>New</option>

</select>
<input type = 'submit' name = 'go' value = 'Search'></form>
<hr color = 'orange'>
<table width = '100%' style = 'border-collapse: collapse;'><tr><th>#</th><th>Names</th><th>Email</th><th>Phone</th><th>Message<th>Date
</th><th></th></tr>
<?php
while( @$adsrow = mysqli_fetch_assoc( $inq_qry ) ) {
    $id = $adsrow['id'];
    $names = $adsrow['names'];
    $phonenumber = $adsrow['phonenumber'];
    $emailaddress = $adsrow['emailaddress'];
    $message = $adsrow['message'];
    $date = $adsrow['date_time'];
    $status = $adsrow['status'];
    if ( $status == 'New' ) {
        echo '<tr style="background-color:cyan; font-weight:bold"><td style="border:1px solid pink;">'.$id.'</td><td style="border:1px solid pink;">'.$names.'</td><td style="border:1px solid pink;">'.$emailaddress.'</td><td style="border:1px solid pink;">'.$phonenumber.'</td><td style="border:1px solid pink;">'.$message.'</td><td style="border:1px solid pink;">'.$date.'</td><td style="border:1px solid pink;"><a href="readcontact.php?id='.$id.'&sq='.$sq.'"><img src="../images/view.png" width="20" height="20"></a> <a href="deletecontact.php?id='.$id.'&sq='.$sq.'"><img src="../images/delete.ico" width="20" height="20"></a></td></tr>';
    } else {
        echo '<tr style="background-color:cyan;"><td style="border:1px solid pink;">'.$id.'</td><td style="border:1px solid pink;">'.$names.'</td><td style="border:1px solid pink;">'.$emailaddress.'</td><td style="border:1px solid pink;">'.$phonenumber.'</td><td style="border:1px solid pink;">'.$message.'</td><td style="border:1px solid pink;">'.$date.'</td><td style="border:1px solid pink;"><a href="readcontact.php?id='.$id.'&sq='.$sq.'"><img src="../images/view.png" width="20" height="20"></a> <a href="deletecontact.php?id='.$id.'&sq='.$sq.'"><img src="../images/delete.ico" width="20" height="20"></a></td></tr>';
    }

}
?>
</table>
</td></tr></table>
</div>
</td></tr></table>