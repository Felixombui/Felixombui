<?php
include 'headers.php';
if ( isset( $_POST['login'] ) ) {
    $username = addslashes( $_POST['username'] );
    $password = addslashes( $_POST['password'] );
    if ( empty( $username ) ) {
        $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">You must enter your username!';
    } else {
        if ( empty( $password ) ) {
            $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">You must enter your password!';
        } else {
            $password = md5( $password, false );
            $loginqry = mysqli_query( $config, "SELECT * FROM `admin` WHERE username='$username' AND password='$password' " );
            if ( mysqli_num_rows( $loginqry )>0 ) {
                $loginrow = mysqli_fetch_assoc( $loginqry );
                $_SESSION['admin'] = $loginrow['fullnames'];
                $_SESSION['admin_username'] = $loginrow['username'];
                header( 'location:index.php' );
            } else {
                $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">Login failed! Wrong credentials.';
            }
        }
    }
}
?>
<style>
<?php echo include '../styles.css' ?>
</style>
<div style = 'width:100%; margin-top:150px;' align = 'center'>
<form method = 'post'>
<table style = 'background-color: cyan; box-shadow:2px 2px grey;' width = '20%'>
<tr><th><h3>Login</h3>
</th></tr>
<tr><td style = 'padding-bottom:5px'><img src = '../images/user.png' width = '20' height = '20' align = 'left'><input type = 'text' name = 'username' placeholder = 'Enter Username' style = 'width:87%; float:right;'></td style = 'padding-top:5px'></tr>
<tr><td><img src = '../images/key.png' width = '20' height = '20' align = 'left'><input type = 'password' name = 'password' placeholder = 'Enter Password' style = 'width:87%; float:right;'></td></tr>
<tr><td><input type = 'submit' name = 'login' value = 'Login' style = 'width:87%; float:right;'></td></tr>
<tr><td><?php echo $info ?></td></tr>
</table>
</form>
</div>