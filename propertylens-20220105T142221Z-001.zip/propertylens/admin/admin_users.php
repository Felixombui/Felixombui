<?php
include 'headers.php';
if ( !$_SESSION['admin'] ) {
    header( 'location:admin_login.php' );
}
if ( isset( $_POST['add'] ) ) {
    $fullnames = addslashes( $_POST['fullnames'] );
    $phonenumber = addslashes( $_POST['phonenumber'] );
    $emailaddress = addslashes( $_POST['emailaddress'] );
    $username = addslashes( $_POST['username'] );
    $createpassword = addslashes( $_POST['createpassword'] );
    $confirmpassword = addslashes( $_POST['confirmpassword'] );
    $creationdate = date( 'd/m/Y' );
    if ( empty( $fullnames ) ) {
        $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">You must enter full names!</div>';
    } elseif ( empty( $phonenumber ) ) {
        $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">You must enter phonenumber!</div>';
    } elseif ( empty( $emailaddress ) ) {
        $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">You must enter email address!</div>';
    } elseif ( empty( $username ) ) {
        $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">You must create a username!</div>';
    } elseif ( empty( $createpassword ) ) {
        $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">You must create a password!</div>';
    } else {
        if ( $createpassword == $confirmpassword ) {
            //check if username exists
            $adminqry = mysqli_query( $config, "SELECT * FROM `admin` WHERE username='$username'" );
            if ( mysqli_num_rows( $adminqry )>0 ) {
                $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">The username already exists. Please enter another username!</div>';
            } else {
                $password = md5( $createpassword, false );
                if ( mysqli_query( $config, "INSERT INTO `admin`(fullnames,phonenumber,emailaddress,username,`password`,creationdate) VALUES('$fullnames','$phonenumber','$emailaddress','$username','$password','$creationdate')" ) ) {
                    $info = '<div class="success"><img src="../images/success.png" width="20" height="20" align="left">Admin account created successfully.</div>';
                } else {
                    $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">Account creation failed!</div>';
                }
            }
        } else {
            $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left">Your passwords do not match!</div>';
        }
    }

}

?>
<style>
<?php echo include '../styles.css' ?>
</style>
<table width = '99%' style = 'height: 100%;'><tr><td>
<div style = 'float: left; width:20%; background-color:cyan; height:100%; border-right:1px solid orange'>
<table width = '100%' class = 'adminmenu'>
<tr><td><a href = 'index.php'><img src = '../images/cpanel.png' width = '20' height = '20' align = 'left'>Main Panel</a></td></tr>
<tr><td><a href = 'adverts.php'><img src = '../images/ads.png' width = '20' height = '20' align = 'left'>Adverts</a></td></tr>
<tr><td><a href = 'inquiries.php'><img src = '../images/inquiry.png' width = '20' height = '20' align = 'left'>Inquiries</a></td></tr>
<tr><td><a href = 'contacts.php'><img src = '../images/contacts.png' width = '20' height = '20' align = 'left'>Contacts</a></td></tr>
<tr><td><a href = 'users.php?sq=Buyer'><img src = '../images/buyers.png' width = '20' height = '20' align = 'left'>Buyers</a></td></tr>
<tr><td><a href = 'users.php?sq=Seller'><img src = '../images/sellers.png' width = '20' height = '20' align = 'left'>Sellers</a></td></tr>
<tr><td><a href = 'users.php?sq=Agent'><img src = '../images/agents.png' width = '20' height = '20' align = 'left'>Agents</a></td></tr>
<tr><td><a href = 'users.php?sq=Landlord'><img src = '../images/landlords.png' width = '20' height = '20' align = 'left'>Landlords</a></td></tr>
<tr><td><a href = 'emails.php'><img src = '../images/emails.png' width = '20' height = '20' align = 'left'>Emails sent</a></td></tr>
<tr><td><a href = 'sms.php'><img src = '../images/sms.png' width = '20' height = '20' align = 'left'>Messages Sent</a></td></tr>
<tr><td><a href = 'admin_users.php'><img src = '../images/user.png' width = '20' height = '20' align = 'left'>Admin Users</a></td></tr>
</table>
</div>
<div style = 'float:right; width:78%;'>
<div style = 'float:left; width:49%; margin:5px;'>
<table width = '100%' style = 'border-collapse: collapse; border:1px solid pink;'><tr><th>Admin Users</th></tr>
<?php
$usrqry = mysqli_query( $config, 'SELECT * FROM `admin`' );
while( $usrrow = mysqli_fetch_assoc( $usrqry ) ) {
    $usrid = $usrrow['id'];
    echo '<tr><td><a href="userprofile.php?id='.$usrid.'"><img src="../images/user.png" width="20" height="20" align="left">'.$usrrow['fullnames'].'</td></tr>';
}
?>
<tr><td></td></tr>

</table>
</div>
<div style = 'float:left; width:49%; margin:5px;'>
<table width = '100%' style = 'border-collapse: collapse; border:1px solid pink;'><tr><th>New Admin Users</th></tr>
<tr><td>
<form method = 'post'>
<table>
<tr><td>Full Names</td><td><input type = 'text' name = 'fullnames' size = '32'></td></tr>
<tr><td>Phone Number</td><td><input type = 'tel' name = 'phonenumber' size = '32'></td></tr>
<tr><td>Email Address</td><td><input type = 'email' name = 'emailaddress' size = '32'></td></tr>
<tr><td>Username</td><td><input type = 'text' name = 'username' size = '32'></td></tr>
<tr><td>Create Password</td><td><input type = 'password' name = 'createpassword' size = '32'></td></tr>
<tr><td>Confirm Password</td><td><input type = 'password' name = 'confirmpassword' size = '32'></td></tr>
<tr><td></td><td><input type = 'submit' name = 'add' value = 'Add Admin User' size = '32'></td></tr>
</table>
<table><tr><td><?php echo $info ?></td></tr></table>
</form>
</td></tr>
</table>
</div>
</div>
</td></tr></table>