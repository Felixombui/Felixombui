<?php
include 'headers.php';
if ( !$_SESSION['admin'] ) {
    header( 'location:admin_login.php' );
}
$sq = $_GET['sq'];
$id = $_GET['id'];
$query = mysqli_query( $config, "SELECT * FROM contacts WHERE id='$id'" );
$qrow = mysqli_fetch_assoc( $query );
mysqli_query( $config, "UPDATE contacts set `status`='Seen' where id='$id'" );
if ( isset( $_POST['submit'] ) ) {
    $names = addslashes( $qrow['names'] );
    $emailaddress = addslashes( $qrow['emailaddress'] );
    $reply = addslashes( $_POST['reply'] );
    $date = date( 'd/m/Y h:mA' );
    @mail( $qrow['emailaddress'], 'Reply from Kenya Property Market', $reply, 'From:info@macrasystems.com' );
    mysqli_query( $config, "INSERT INTO emails(names,emailaddress,`subject`,`message`,date_time) VALUES('$names','$emailaddress','Reply `from` Kenya Property Market','$reply','$date' )" );
    $info = '<div class="success"><img src="../images/success.png" width="20" height="20" align="left"> Reply emailed successfully.';
    if ( isset( $_POST['sms'] ) ) {
        $msgchars = strlen( $reply );
        if ( $msgchars>480 ) {
            $info = '<div class="error"><img src="../images/error.png" width="20" height="20" align="left"> The reply is too long to be sent on sms. Reply has been sent by email.';
        } else {
            $phonenumber = $qrow['phonenumber'];
            $chars = strlen( $phonenumber );
            if ( $chars<11 ) {
                $trimphone = ltrim( $phonenumber, '0' );
                $phonenumber = '254'.$trimphone;
            }
            $message = urlencode( $reply );
            $url = 'https://sms.macrasystems.com/sendsms/index.php?username=mankan&senderid=SMARTLINK&phonenumber='.$phonenumber.'&message='.$message;
            file_get_contents( $url );
            mysqli_query( $config, "INSERT INTO sms(names,phonenumber,`message`,date_time) VALUES('$names','$phonenumber','$reply','$date')" );
            $info = '<div class="success"><img src="../images/success.png" width="20" height="20" align="left"> Email and SMS sent successfully.';
        }
    }
}
?>
<style>
<?php echo include '../styles.css' ?>
</style>
<table width = '99%' style = 'height: 100%;
            '><tr><td>
<div style = 'float: left;
            width:20%;
            background-color:cyan;
            height:100%;
            border-right:1px solid orange'>
<table width = '100%' class = 'adminmenu'>
<tr><td><a href = 'index.php'><img src = '../images/cpanel.png' width = '20' height = '20' align = 'left'>Main Panel</a></td></tr>
<tr><td><a href = 'adverts.php'><img src = '../images/ads.png' width = '20' height = '20' align = 'left'>Adverts</a></td></tr>
<tr><td><a href = 'inquiries.php'><img src = '../images/inquiry.png' width = '20' height = '20' align = 'left'>Inquiries</a></td></tr>
<tr><td><a href = 'contacts.php'><img src = '../images/contacts.png' width = '20' height = '20' align = 'left'>Contacts</a></td></tr>
<tr><td><a href = 'users.php?sq = Buyer'><img src = '../images/buyers.png' width = '20' height = '20' align = 'left'>Buyers</a></td></tr>
<tr><td><a href = 'users.php?sq = Seller'><img src = '../images/sellers.png' width = '20' height = '20' align = 'left'>Sellers</a></td></tr>
<tr><td><a href = 'users.php?sq = Agent'><img src = '../images/agents.png' width = '20' height = '20' align = 'left'>Agents</a></td></tr>
<tr><td><a href = 'users.php?sq = Landlord'><img src = '../images/landlords.png' width = '20' height = '20' align = 'left'>Landlords</a></td></tr>
<tr><td><a href = 'emails.php'><img src = '../images/emails.png' width = '20' height = '20' align = 'left'>Emails sent</a></td></tr>
<tr><td><a href = 'sms.php'><img src = '../images/sms.png' width = '20' height = '20' align = 'left'>Messages Sent</a></td></tr>
</table>
</div>
<div style = 'float:right;
            width:78%;
            '>
<table width = '100%'><tr><td>
<form method = 'post'><?php echo '<a href = "contacts.php?sq='.$sq.'"><< Back </a>' ?></form>
<hr color = 'orange'>
<table width = '100%' style = 'border-collapse: collapse;
            '><tr><th>Message <?php echo $id ?> From: <?php echo $qrow['names'] ?> | Email: <a href = "mailto:<?php echo $qrow['emailaddress'] ?>"><?php echo $qrow['emailaddress'] ?></a> | Phone: <?php echo $qrow['phonenumber'] ?> </th></tr>
<tr><td>
<table width = '20%'>
<?php
echo '<tr><td>Message:</td><td>'.$qrow['message'].'</td></tr>';
echo '<tr><td>Reply:</td><td><form method = "post"><textarea name = "reply" cols = "40" rows = "5"></textarea><br><input type = "checkbox" name = "sms">Also send as sms<br><input type = "submit" name = "submit" value = "Reply" style = "float:right;
"></td></tr>';
?>
</table>
<?php echo $info ?>
</td></tr>

</table>
</td></tr></table>
</div>
</td></tr></table>