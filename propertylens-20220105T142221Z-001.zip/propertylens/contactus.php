<?php
include 'headers.php';
$searchqry = mysqli_query( $config, "SELECT * FROM adverts WHERE `status`='Approved' ORDER BY id DESC" );
$enquiries = mysqli_query( $config, 'SELECT * FROM enquiries ORDER BY id DESC' );

function custom_echo( $x, $length )
 {
    if ( strlen( $x ) <= $length )
 {
        echo $x;
    } else {
        $y = substr( $x, 0, $length ) . '...';
        echo $y;
    }
}
if ( isset( $_POST['send'] ) ) {
    $names = addslashes( $_POST['names'] );
    $emailaddress = addslashes( $_POST['emailaddress'] );
    $phonenumber = $_POST['phonenumber'];
    $message = addslashes( $_POST['message'] );
    $date = date( 'd/m/Y h:mA' );
    if ( empty( $names ) ) {
        $info = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must enter full names!</div>';
    } else {
        if ( empty( $phonenumber ) ) {
            $info = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must enter your phone number!</div>';
        } else {
            if ( empty( $message ) ) {
                $info = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">Please type a message!</div>';
            } else {
                if ( mysqli_query( $config, "INSERT INTO contacts(names,emailaddress,phonenumber,`message`,date_time) VALUES('$names','$emailaddress','$phonenumber','$message','$date')" ) ) {
                    $adminphone = '254708138498';
                    $message = urlencode( 'You have a contact from Kenya Property Website. Please login as admin to view.' );
                    $url = 'https://sms.macrasystems.com/sendsms/index.php?username=Mankan&senderid=SMARTLINK&phonenumber='.$adminphone.'&message='.$message;
                    file_get_contents( $url );
                    $info = '<div class="success"><img src="images/success.png" width="20" height="20" align="left">Thank you for contacting us. We will get back to you as soon as possible.</div>';

                } else {
                    $info = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">Your message was not sent!</div>';
                }
            }
        }
    }
}
?>
<p>
<table width = '80%' align = 'center'>
<tr><td>
<div style = 'float: left; width:79%'>
<form method = 'post'>
<table width = '60%' align = 'center'>
<tr><td>Names:</td><td><input type = 'text' name = 'names' size = '32' value = "<?php echo $_SESSION['fullnames'] ?>"></td></tr>
<tr><td>Email address:</td><td><input type = 'email' name = 'emailaddress' size = '32' value = "<?php echo $_SESSION['emailaddress'] ?>"></td></tr>
<tr><td>Phone Number:</td><td><input type = 'tel' name = 'phonenumber' size = '32' value = "<?php echo $_SESSION['phonenumber'] ?>"></td></tr>
<tr><td>Message:</td><td><textarea name = 'message' cols = '27'></textarea></td></tr>
<tr><td></td><td><input type = 'submit' name = 'send' value = 'Send Message' size = '32'></td></tr>
</table>
<table width = '60%' align = 'center'><tr><td><?php echo $info ?></td></tr></table>
</form>
</div>
<div style = 'float: right; width:20%'>
<?php
while( $enqrow = mysqli_fetch_assoc( $enquiries ) ) {
    $enqid = $enqrow['id'];
    $comms = mysqli_query( $config, "SELECT id FROM enq_comments WHERE anqid='$enqid'" );
    $comments = mysqli_num_rows( $comms );
    $usernames = $enqrow['usernames'];
    $query = $enqrow['enquiry'];
    $enquirydate = $enqrow['enquirydate'];
    echo '<a href="enquiries.php?eid='.$enqid.'"><table width="100%" style="border:1px solid cyan" class="enquiry"><tr><td>
    <img src="images/user.png" width="30" height="30" align="left"><b>'.$usernames.'</b><br><i>'.$enquirydate.'</i><br>'.$query.'
    <table style="color:blue; font-size:11;"><tr><td>Comments: '.$comments.'</td></tr></table>
    </td></tr></table></a><p>';
}
?>
</div>
</td></tr>
</table>
</p>
<style>
<?php echo include 'styles.css' ?>
</style>
