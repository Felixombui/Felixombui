<?php
include 'headers.php';
if ( isset( $_POST['reset'] ) ) {
    $emailaddress=addslashes($_POST['emailaddress']);
    $recqry=mysqli_query($config,"SELECT * FROM system_users WHERE emailaddress='$emailaddress'");
    if (mysqli_num_rows($recqry)>0){
        $recRow=mysqli_fetch_assoc($recqry);
        $fullnames=$recRow['names'];
        $rand=rand(500000,1000000);
        $token=md5($rand,false);
        $date=date('d-m-Y');
        if(mysqli_query($config,"INSERT INTO recoverytoken(emailaddress,rectoken,tokendate) VALUES('$emailaddress','$token','$date')")){
            mail($emailaddress,'Property Lens Recovery','Dear '.$fullnames.', Please click on the following link to reset your password: https://test.macrasystems.com/changepass.php?t='.$token,'From: info@macrasystems.com');
            $error='<img src="images/success.png" width="20" height="20" align="left"> Success. An email with a link has been sent to you.';
        }else{
            $error='<img src="images/error.png" width="20" height="20" align="left"> We were unable to confirm your identity. Please contact our system administrators.';
        }
    }
}
?>
<p>
<div class = 'formdiv' align = 'center'>
Please enter the email address you registered with
<form method = 'post'>
<table>
<tr><td>Email Address:</td><td><input type = 'email' name = 'emailaddress' size="42"></td></tr>
<tr><td></td><td align = 'right'><input type = 'submit' name = 'reset' value = 'Reset'</td></tr>
</table>
</form>
<table><tr><td><?php echo $error ?></td></tr></table>
</div></p>

<style>
<?php echo include 'styles.css' ?>
</style>
