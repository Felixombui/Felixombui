<?php
include 'headers.php';
$type = $_GET['type'];
$username = $_SESSION['username'];
$userid = $_SESSION['userid'];
if ( isset( $_POST['submit'] ) ) {
    $title = addslashes( $_POST['adtitle'] );
    $description = addslashes( $_POST['description'] );
    $unitcost = $_POST['unitcost'];
    $county = addslashes( $_POST['county'] );
    $locality = addslashes( $_POST['locality'] );
    $propertytype = addslashes( $_POST['type'] );
    $advertowner = addslashes( $username );
    if ( empty( $title ) ) {
        $info = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must have a title for your advert!</div>';
    } else {
        if ( empty( $description ) ) {
            $info = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must have a description for your advert!</div>';
        } else {
            if ( empty( $unitcost ) ) {
                $info = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must set the unit cost!</div>';
            } else {
                if ( empty( $locality ) ) {
                    $info = '<div class="error"><img src="images/error.png" width="20" height="20" align="left">You must tell the public the location of your property!</div>';
                } else {
                    if ( mysqli_query( $config, "INSERT INTO adverts(title,`description`,unitcost,userid,advertowner,county,locality,propertytype) VALUES('$title','$description','$unitcost','$userid','$advertowner','$county','$locality','$propertytype')" ) ) {

                        $idqry = mysqli_query( $config, "SELECT * FROM adverts WHERE userid='$userid' ORDER BY id DESC limit 1" );
                        $idrow = mysqli_fetch_assoc( $idqry );
                        $adid = $idrow['id'];

                        //prepare images for upload
                        //if ( !empty( $_POST['image'] ) ) {
                        $filecounter = count( $_FILES['image']['name'] );
                        $filecounter = $filecounter+1;
                        //loop through all files
                        for ( $i = 0; $i < $filecounter; $i++ ) {

                            $filename = $_FILES['image']['name'][$i];
                            $ext = pathinfo($filename, PATHINFO_EXTENSION);
                            $random=rand(10000,50000);
                            $newfilename='file_'.$random.'.'.$ext;
                            //upload file
                            move_uploaded_file( $_FILES['image']['tmp_name'][$i], 'adimages/'.$newfilename );
                            //save to db
                            mysqli_query( $config, "INSERT INTO images(adno,imgname,imglocation) VALUES('$adid','$newfilename','adimages/$newfilename')" );
                            //echo $filename .' uploaded<br>';                      
                        }
                        
                        //}
                        $userphone = $_SESSION['phonenumber'];
                        $chars = strlen( $userphone );
                        if ( $chars<11 ) {
                            $newphone = ltrim( $userphone, '0' );
                            $userphone = '254'.$newphone;
                        }
                        $sms = urlencode( 'Dear '.$username.', Your advert has been received. It will be reviewed for display on Property Lens website. Advert id: '.$adid.'. Thank you.' );
                        $url = 'https://sms.macrasystems.com/sendsms/index.php?username=Mankan&senderid=SMARTLINK&phonenumber='.$userphone.'&message='.$sms;
                        file_get_contents( $url );
                        $info = "<div class = 'success'><img src = 'images/success.png' width = '20' height = '20' align = 'left'>Advert has been submitted successfully. It will show once it is approved. Thank you.<a href = 'myadverts.php'><button>Ok</button></div>";
                        if($propertytype=='Land'){
                            $redirect="landinfo.php";
                        }elseif($propertytype=='House'){
                            $redirect="houseinfo.php";
                        }elseif($propertytype=="Home"){
                            $redirect="houseinfo.php";
                        }  
                        header('location:'.$redirect);
                    } else {
                        $info = "<div class = 'error'><img src = 'images/error.png' width = '20' height = '20' align = 'left'>Unable to submit your advert! Please try again.</div>";
                    }
                }
            }
        }
    }
}
?>
<p>
<style>
.headertable {
    border-collapse: collapse;
    border-bottom: 1px cyan solid;
    border-right: 1px cyan solid;
    border-left: 1px cyan solid;
    box-shadow: 1px 1px cyan;
}

</style>
<table  align = 'center' width = '80%' class = 'headertable'><tr class = 'profileheader'><td>
<table><tr><td><div class = 'linkbutton'><a href = 'profile.php'>Basic info</a></div>  <div class = 'linkbutton'><a href = 'moreinfo.php'>More info</a></div> <div class = 'linkbutton'><a href = 'myadverts.php'>My Ads</a></div> <div class = 'linkbutton'><a href = 'myposts.php'>My Posts</a></div></td></tr></table>
</td></tr>
<tr><td>
<form method = 'post' enctype = 'multipart/form-data'>
<table width = '50%' align = 'center'><tr>
<td>Advert Title</td>
<td><input type = 'text' name = 'adtitle' size = '28'></td>
</tr>
<tr><td>Description</td><td><textarea name = 'description' rows = '5' cols = '24'></textarea></td></tr>
<tr><td>Unit Cost</td><td><input type = 'number' name = 'unitcost' size = '28' value = '0'></td></tr>
<tr><td>County</td><td>
<select name = 'county' style = 'width:210'>
<option>Mombasa</option>
<option>Kwale</option>
<option>Kilifi</option>
<option>Tana River</option>
<option>Lamu</option>
<option>Taita Taveta</option>
<option>Garissa</option>
<option>Wajir</option>
<option>Mandera</option>
<option>Marsabit</option>
<option>Isiolo</option>
<option>Meru</option>
<option>Taraka Nithi</option>
<option>Embu</option>
<option>Kitui</option>
<option>Machakos</option>
<option>Makueni</option>
<option>Nyandarua</option>
<option>Nyeri</option>
<option>Kirinyaga</option>
<option>Murang'a</option>
                        <option>Kiambu</option>
                        <option>Turkana</option>
                        <option>West Pokot</option>
                        <option>Trans-Nzoia</option>
                        <option>Uasin Gishu</option>
                        <option>Elgeyo Marakwet</option>
                        <option>Nandi</option>
                        <option>Baringo</option>
                        <option>Laikipia</option>
                        <option>Nakuru</option>
                        <option>Narok</option>
                        <option>Kajiado</option>
                        <option>Kericho</option>
                        <option>Bomet</option>
                        <option>Kakamega</option>
                        <option>Vihiga</option>
                        <option>Bungoma</option>
                        <option>Busia</option>
                        <option>Siaya</option>
                        <option>Kisumu</option>
                        <option>Homabay</option>
                        <option>Kisii</option>
                        <option>Nyamira</option>
                        <option>Nairobi</option>
                        </select>
                        </td></tr>
                        <tr><td>Location</td><td><input type = 'text' name = 'locality' size = '28'></td></tr>
                        <tr><td>Property Type:</td><td>
                        <select name = 'type' style = 'width:210'>
                        <option>Land</option>
                        <option>House</option>
                        <option>Rentals</option>
                        <option>Apartment</option>
                        <option>School</option>
                        <option>Hotel</option>
                        <option>Home</option>
                        </select>
                        </td></tr>
                        <tr><td>Select Images</td><td><input type = 'file' name = 'image[]' multiple></td></tr>
                        
                        <tr><td></td><td><input type = 'submit' name = 'submit' value = 'Submit Advert' style = 'width:210;
border-radius:5px;
padding:5px'></td></tr>
                        </table>
                        <table width = '50%' align = 'center'><tr><td><?php echo $info ?></td></tr></table>
                        </form>
                        </td></tr>
                        </table>
                        </p>
                        <style>
                        <?php echo include 'styles.css' ?>
</style>