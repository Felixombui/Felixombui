<?php
include 'headers.php';
$searchqry = mysqli_query( $config, "SELECT * FROM adverts WHERE `status`='Approved' ORDER BY id DESC" );
$enquiries = mysqli_query( $config, 'SELECT * FROM enquiries ORDER BY id DESC' );

function custom_echo( $x, $length )
 {
    if ( strlen( $x ) <= $length )
 {
        echo $x;
    } else {
        $y = substr( $x, 0, $length ) . '...';
        echo $y;
    }
}
?>
<p>
<table width = '80%' align = 'center'>
<tr><td>
<div style = 'float: left; width:79%'>
<?php
while( $resrow = mysqli_fetch_assoc( $searchqry ) ) {
    $title = $resrow['title'];
    $description = $resrow['description'];
    $cost = $resrow['unitcost'];
    $owner = $resrow['advertowner'];
    $userid = $resrow['userid'];
    $id = $resrow['id'];
    $location = $resrow['county'].','.$resrow['locality'];
    $imgqry = mysqli_query( $config, "SELECT * FROM images WHERE adno='$id' LIMIT 1" );
    $imgrow = mysqli_fetch_assoc( $imgqry );
    $image = $imgrow['imglocation'];
    $imgtype=explode('.',$image);
    $ext=$imgtype[1];
    echo'<a href="viewad.php?id='.$id.'"><table width="100%" style="box-shadow:1px 1px cyan"><tr><td>';
    if($ext=='png' || $ext=='jpg' || $ext=='jpeg' || $ext=='gif' || $ext=='PNG' || $ext=='JPG' || $ext=='JPEG' || $ext=='GIF' ){
        echo '<img src="'.$image.'" width="30%" height="150" align="left" style="padding:5px;">';
    }elseif($ext == 'mov' || $ext == 'avi' || $ext == 'mpeg' || $ext == 'mkv' || $ext == 'mp4' || $ext == 'vob' || $ext == 'MOV' || $ext == 'AVI' || $ext == 'MPEG' || $ext == 'MKV' || $ext == 'MP4' || $ext == 'VOB'){
        echo '<video width="30%" height="150" align="left" style="padding:5px;">
        <source src="'.$image.'" type="video/'.$ext.'">';
    }
    echo '<table width="68%" align="right"><tr><th>'.$title.'</th></tr>
    
    <tr><td>';
    custom_echo( $description, 100 );
    echo '</td></tr>
    <tr><td>
    Location: '.$location.'
    <table width = "100%"><tr><td><b>Cost: '.number_format( $cost, 2 ).'</td><td><b>Owner: '.$owner.'</b></td></tr></table>
    <div align="right"><a href="contactowner.php?userid='.$userid.'&id='.$id.'"><button class="searchbutton"><img src="images/call.png" width="20" height="20" align="left">Contact Seller</button></a></div>
    </table>
    </td></tr></table></a><p>';
}
?>
</div>
<div style = 'float: right; width:20%'>
<?php
while( $enqrow = mysqli_fetch_assoc( $enquiries ) ) {
    $enqid = $enqrow['id'];
    $comms = mysqli_query( $config, "SELECT id FROM enq_comments WHERE anqid='$enqid'" );
    $comments = mysqli_num_rows( $comms );
    $usernames = $enqrow['usernames'];
    $query = $enqrow['enquiry'];
    $enquirydate = $enqrow['enquirydate'];
    echo '<a href="enquiries.php?eid='.$enqid.'"><table width="100%" style="border:1px solid cyan" class="enquiry"><tr><td>
    <img src="images/user.png" width="30" height="30" align="left"><b>'.$usernames.'</b><br><i>'.$enquirydate.'</i><br>'.$query.'
    <table style="color:blue; font-size:11;"><tr><td>Comments: '.$comments.'</td></tr></table>
    </td></tr></table></a><p>';
}
?>
</div>
</td></tr>
</table>
</p>
<style>
<?php echo include 'styles.css' ?>
</style>
