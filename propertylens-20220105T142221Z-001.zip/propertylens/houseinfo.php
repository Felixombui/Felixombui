<?php
include 'headers.php';
$type = $_GET['type'];
$username = $_SESSION['username'];
$userid = $_SESSION['userid'];
$qry=mysqli_query($config,"SELECT * FROM adverts WHERE userid='$userid' ORDER BY id DESC LIMIT 1");
$adrow=mysqli_fetch_assoc($qry);
$adid=$adrow['id'];
$adtitle=$adrow['title'];
if(isset($_POST['submit'])){
    $adid=addslashes($id);
    $moreinfo='Size: '.$_POST['landsize'].',Plot No: '.$_POST['plotno'].'Number of Rooms: '.$_POST['noofrooms'].',More Info: '.$_POST['moreinfo'];
    $description=addslashes($moreinfo);
    if(mysqli_query($config,"INSERT INTO moreinfo(adid,`description`) VALUES('$adid','$description')")){
        $info='<img src="images/success.png" width="20" height="20" align="left"> Advert has been submitted successfully.';
    }else{
        $info='<img src="images/error.png" width="20" height="20" align="left"> Advert submission failed.';
    }
}
?>
<p>
<style>
.headertable {
    border-collapse: collapse;
    border-bottom: 1px cyan solid;
    border-right: 1px cyan solid;
    border-left: 1px cyan solid;
    box-shadow: 1px 1px cyan;
}

</style>
<table  align = 'center' width = '80%' class = 'headertable'><tr class = 'profileheader'><td>
<table><tr><td><div class = 'linkbutton'><a href = 'profile.php'>Basic info</a></div>  <div class = 'linkbutton'><a href = 'moreinfo.php'>More info</a></div> <div class = 'linkbutton'><a href = 'myadverts.php'>My Ads</a></div> <div class = 'linkbutton'><a href = 'myposts.php'>My Posts</a></div></td></tr></table>
</td></tr>
<tr><td>
<form method = 'post' enctype = 'multipart/form-data'>
<table style="background-color: cyan; width:100%;"><tr><td>Advert No: <?php echo '<b>'.$adid.'</b>' ?> Advert Title: <?php echo '<b>'.$adtitle.'</b>' ?></td></tr></table>
<table>

    <tr><td>Size</td><td><input type="text" name="landsize"></td></tr>
    <tr><td>Plot Number</td><td><input type="text" name="plotno"></td></tr>
    <tr><td>Number of Rooms</td><td><input type="text" name="noofrooms"></td></tr>
    <tr><td>More Info</td><td><textarea cols="10" rows="5" name="moreinfo"></textarea></td></tr>
    <tr><td>&nbsp;</td><td><input type="submit" name="submit" value="Submit Info"></td></tr>
</table>
<table width="50%" align="center"><tr><td><?php echo $info ?></td></tr></table>
                        </form>
                        </td></tr>
                        </table>
                        </p>
                        <style>
                        <?php echo include 'styles.css' ?>
</style>