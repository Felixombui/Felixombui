<?php
include 'headers.php';
$t=$_GET['t'];
$tqry=mysqli_query($config,"SELECT * FROM recoverytoken WHERE rectoken='$t'");
if(mysqli_num_rows($tqry)>0){
    $trow=mysqli_fetch_assoc($tqry);
    $emailaddress=$trow['emailaddress'];
    $status=$trow['tokenstatus'];
    if($status=='Pending'){
        $info='<form method="post"><table><tr><td>New Password: </td><td><input type="password" name="newpassword" required="required"></td></tr>
        <tr><td>Confirm Password:</td><td><input type="password" name="repeatpassword" required="required"></td></tr>
        <tr><td>&nbsp;</td><td><input type="submit" name="changepassword" value="Change Password"></td></tr></table>'; 
    }else{
        $info='<img src="images/error.png" width="20" height="20"> This link has already been used! Please try requesting again.';
    }
}else{
    $info='<img src="images/error.png" width="20" height="20"> This link you clicked does not exist!.';
}
if(isset($_POST['changepassword'])){
    $newpassword=addslashes($_POST['newpassword']);
    $newpass=md5($newpassword,false);
    if(mysqli_query($config,"UPDATE system_users SET password='$newpass' WHERE emailaddress='$emailaddress'")){
        mysqli_query($config,"UPDATE recoverytoken SET tokenstatus='Used' WHERE rectoken='$t'");
        $info='<img src="images/success.png" width="20" height="20"> You have succesfully changed your password <a href="signin.php">Sign in now</a>.';
    }
}


?>
<p>
<div class = 'formdiv' align = 'center'>
<?php echo $info ?>

</div></p>

<style>
<?php echo include 'styles.css' ?>
</style>
