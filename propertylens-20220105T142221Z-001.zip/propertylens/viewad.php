<?php
include 'headers.php';
$id = $_GET['id'];
$searchqry = mysqli_query( $config, "SELECT * FROM adverts WHERE id='$id'" );
$enquiries = mysqli_query( $config, 'SELECT * FROM enquiries ORDER BY id DESC' );
?>
<html>
<link rel = 'stylesheet' href = 'https://www.w3schools.com/w3css/4/w3.css'>
<style>
.mySlides {
    display:none;
}
</style>
<?php
$getimgs=mysqli_query($config,"SELECT * FROM images WHERE adno='$id'");
$noofimgs=mysqli_num_rows($getimgs);
?>

</div>

<body>
    <table width="80%" align="center"><tr><td align="left">
    <div class="w3-content w3-display-container" style="height: 200px; width:80%; float:left;">
    <?php
    $imgid=0;
    while($getrow=mysqli_fetch_assoc($getimgs)){
        $img=$getrow['imglocation'];
        $imgid=$imgid+1;
        echo '<div class="slideshow-container">
        <div class="mySlides fade">';
        $imgtype=explode('.',$img);
        $ext=$imgtype[1];
        if ($ext == 'gif' || $ext == 'png' || $ext == 'jpg' || $ext=='PNG' || $ext=='JPG' || $ext=='JPEG' || $ext=='GIF'){
          echo '<img src="'.$img.'" style="width:100%" height="400px">';
        }elseif($ext == 'mov' || $ext == 'avi' || $ext == 'mpeg' || $ext == 'mkv' || $ext == 'mp4' || $ext == 'vob' || $ext == 'MOV' || $ext == 'AVI' || $ext == 'MPEG' || $ext == 'MKV' || $ext == 'MP4' || $ext == 'VOB'){
          echo '<video width="100%" height="400" controls>
          <source src="'.$img.'" type="video/'.$ext.'">';
        }
        echo '<div class="text">'.$imgid.'/'.$noofimgs.'Type:'.$ext.'</div>
        </div>
        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>
            </div>
        ';
    }
    echo '<div style="text-align:center">';
     for($i=1; $i<$noofimgs+1; $i++){
       echo '<span class="dot" onclick="currentSlide('.$i.')"></span>';
     }
     echo '</div>';
    ?>
    <!--Image functions-->
    
    <script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>


    <!--end of image functions-->
    <div style="float: left; width:80%;">
    <?php
    $qry=mysqli_query($config,"SELECT * FROM adverts WHERE id='$id'");
    $qrow=mysqli_fetch_assoc($qry);
    $userid=$qrow['userid'];
      //echo $qrow['title'];
    ?>
    
    </div>
    <table width="100%"><tr><th>
      <?php echo $qrow['title'] ?>
    </th></tr>
    <tr><td><?php echo $qrow['description'] ?></td></tr>
    <tr><td>Cost: <?php echo number_format($qrow['unitcost'],0) ?></td></tr>
    <tr><td align="right"><?php echo '<a href="contactowner.php?id='.$id.'&userid='.$userid.'"><button class="searchbutton">Contact Owner</button>' ?></td></tr>
    <tr><td>&nbsp;</td></tr>
  </table>
</div>
</div>
<div style = 'float: right; width:19%'>
<?php
while( $enqrow = mysqli_fetch_assoc( $enquiries ) ) {
    $enqid = $enqrow['id'];
    $comms = mysqli_query( $config, "SELECT id FROM enq_comments WHERE anqid='$enqid'" );
    $comments = mysqli_num_rows( $comms );
    $usernames = $enqrow['usernames'];
    $query = $enqrow['enquiry'];
    $enquirydate = $enqrow['enquirydate'];
    echo '<a href="enquiries.php?eid='.$enqid.'"><table width="100%" style="border:1px solid cyan" class="enquiry"><tr><td>
    <img src="images/user.png" width="30" height="30" align="left"><b>'.$usernames.'</b><br><i>'.$enquirydate.'</i><br>'.$query.'
    <table style="color:blue; font-size:11;"><tr><td>Comments: '.$comments.'</td></tr></table>
    </td></tr></table></a><p>';
}
?>

</div>
    </td></tr></table>
</body>
</html>
<style>
<?php
echo include 'styles.css';
?>
</style>
