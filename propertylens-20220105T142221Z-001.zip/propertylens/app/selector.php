<?php
//header('refresh:5;url=selector.php');
?>
<div class="loginform" style="text-align: center;">
    <img src="../images/logo.png" width="250" height="250" style="margin-top:5%;"><br>  
    <a href="login.php"><button style="float:left;width:45%;padding:10px;background-color:blue;color:white;border-radius:6px;">Login</button></a><a href="signup.php"><button style="float:right;width:45%;padding:10px;background-color:blue;color:white;border-radius:6px;">Register</button></a> 
</div>
<?php
include 'styles.html';
?>