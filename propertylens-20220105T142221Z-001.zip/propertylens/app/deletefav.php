<?php
include '../config.php';
$id=$_GET['id'];
mysqli_query($config,"DELETE FROM favs WHERE id='$id'");
header('location:fav.php');
?>