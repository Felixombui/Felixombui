<?php
include '../config.php';
//login
if(!isset($_COOKIE['userdetail'])){
    if(isset($_POST['login'])){
        $username=addslashes($_POST['username']);
        $password=addslashes($_POST['password']);
        $encpass=md5($password);
        $loginqry=mysqli_query($config,"SELECT * FROM system_users WHERE username='$username' AND `password`='$encpass'");
        if(mysqli_num_rows($loginqry)>0){
            //pick ccount information
            $loginrow=mysqli_fetch_assoc($loginqry);
            //check account status
            $status=$loginrow['status'];
            $emailaddress=$loginrow['emailaddress'];
            if($status=='Pending'){
                $result='<img src="../images/error.png" width="23" height="23" align="left"> Your account status is pending. <a href="confirmationlink.php?email='.$emailaddress.'">Resend Confirmation Link.</a>';
            }elseif($status=='Blocked'){
                $result='<img src="../images/error.png" width="23" height="23" align="left"> Your account is blocked!';
            }elseif($status=='Active'){
                //allow login
                session_start();
                $_SESSION['id']=$loginrow['id'];
                $_SESSION['username']=$loginrow['username'];
                $_SESSION['names']=$loginrow['names'];
                $_SESSION['emailaddress']=$loginrow['emailaddress'];
                $_SESSION['gender']=$loginrow['gender'];
                $_SESSION['user']='Logged';
                setcookie('userdetail',$username.','.$encpass,time()+(10*365*60*60));
                header('location:home.php');
            }
                
        }else{
            $result='<img src="../images/error.png" width="23" height="23" align="left"> Login failed. Please check your username and/or password.';
        }
            
        
    }
}else{
    //auto login using cookie
    $usercookie=explode(',',$_COOKIE['userdetail']);
    $username=$usercookie[0];
    $password=$usercookie[1];
    $loginqry=mysqli_query($config,"SELECT * FROM system_users WHERE username='$username' AND `password`='$password'");
        if(mysqli_num_rows($loginqry)>0){
            //pick ccount information
            $loginrow=mysqli_fetch_assoc($loginqry);
            //check account status
            $status=$loginrow['status'];
            $emailaddress=$loginrow['emailaddress'];
            if($status=='Pending'){
                $result='<img src="../images/error.png" width="23" height="23" align="left"> Your account status is pending. <a href="confirmationlink.php?email='.$emailaddress.'">Resend Confirmation Link.</a>';
            }elseif($status=='Blocked'){
                $result='<img src="../images/error.png" width="23" height="23" align="left"> Your account is blocked!';
            }elseif($status=='Active'){
                //allow login
                session_start();
                $_SESSION['id']=$loginrow['id'];
                $_SESSION['username']=$loginrow['username'];
                $_SESSION['names']=$loginrow['names'];
                $_SESSION['emailaddress']=$loginrow['emailaddress'];
                $_SESSION['gender']=$loginrow['gender'];
                $_SESSION['user']='Logged';
                setcookie('userdetail',$username.','.$encpass,time()+(10*365*60*60));
                header('location:home.php');
            }
                
        }else{
           
            setcookie('userdetail','',time()-3600);
            $result='<img src="../images/error.png" width="23" height="23" align="left"> Your login details might have changed since your last login<br>';
        }
}

?>
<script>
function viewPassword() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script> 
<form method="post">
    
    <div class="loginform">
    <div style="text-align: center;"><img src="../images/logo.png" width="180" height="180"></div>
        <input type="text" name="username" placeholder="Enter your username..." required="required">
        <input type="password" name="password" id="password" placeholder="Enter your password" required="required" style="margin-bottom: 8px;">
        <div style="width: 100%;text-align:left"><input type="checkbox" onclick="viewPassword()" style="width:auto;margin-top:8px;margin-bottom:8px;"> Show Password</div>
        <input type="submit" name="login" value="Login" class="loginbutton""><br>
        <a href="recover.php" style="text-align: center;">I forgot my password</a> | <a href="signup.php">Register Now free</a><p>
            <?php echo $result ?>
        </p>
    </div>

</form>

<?php
include 'styles.html';
?>