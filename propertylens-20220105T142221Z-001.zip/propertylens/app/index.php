<?php
header('refresh:5;url=selector.php');
?>
<div class="splash">
    <img src="../images/logo.png" width="250" height="250" style="margin-top:40%;" class="fade-in">   
</div>
<?php
include 'styles.html';
?>