<?php
include '../config.php';
$account=$_GET['account'];
//new cURL function
function get_web_page( $myurl )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );

    $ch      = curl_init( $myurl );
    curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    return $header;
}
//end of function
if(isset($_POST['recover'])){
    $code=addslashes($_POST['code']);
    $code=md5($code);
    $qry=mysqli_query($config,"SELECT * FROM resetcode WHERE account='$account' AND resetcode='$code'");
    if(mysqli_num_rows($qry)>0){
        $row=mysqli_fetch_assoc($qry);
        $status=$row['status'];
        if($status=='Used'){
            $result='<img src="../images/error.png" width="23" height="23" align="left"> The code you entered has already been used!';
        }else{
            mysqli_query($config,"UPDATE resetcode set `status`='Used' WHERE account='$account'");
            header('location:resetpassword.php?account='.$account);
        }

    }else{
        $result='<img src="../images/error.png" width="23" height="23" align="left"> Wrong code. Try again.';
    }
}
?>

<form method="post">
    
    <div class="loginform">
    <img src="../images/logo.png" width="180" height="180"><p>
    <b>Enter the code you have received on sms</b>
        <input type="text" name="code" placeholder="Enter the code you have received on sms...">
        <input type="submit" class="loginbutton" name="recover" value="Submit code">
        <p>
            <?php echo $result ?>
        </p>
        <a href="recover.php">Resend Code</a>
    </div>

</form>

<?php
include 'styles.html';
?>