<?php
include '../config.php';
$account=$_GET['accid'];
//new cURL function
function get_web_page( $myurl )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );

    $ch      = curl_init( $myurl );
    @curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    return $header;
}
//end of function
if(isset($_POST['change'])){
    $phonenumber=addslashes($_POST['phonenumber']);
    if (strlen($_POST['phonenumber'])<10){
        $result='<img src="../images/error.png" width="23" height="23" align="left"> Incorrect phone number!';
    }else{
        mysqli_query($config,"UPDATE system_users SET phonenumber='$phonenumber' WHERE id='$account'");
         //create confirmation code
         $confirmationcode=rand(1000,9999);
         $encCode=md5($confirmationcode);
         //find my new account id
         $accqry=mysqli_query($config,"SELECT * FROM system_users WHERE phonenumber='$phonenumber'");
         $accrow=mysqli_fetch_assoc($accqry);
         $accid=$accrow['id'];
         mysqli_query($config,"INSERT INTO resetcode(account,resetcode) VALUES('$accid','$encCode')");            
         //send welcome sms
         $message=urlencode('Dear '.$names.'. Welcome to Property Lens. The largest property market. Use '.$confirmationcode.' as your confirmation code.');
       $url='http://macrasms.macrasystems.com/sendsms.php?senderid=PROPERTYLNS&phonenumber='.$phonenumber.'&message='.$message;
      get_web_page($url);
      header('location:confirmationcode.php?p='.$phonenumber.'&account='.$account);
    }
}
?>
<div style="background-color: cyan;color:green;margin-top:30%;">
<h2>Change Phone Number</h2>

<form method="post">
    <input type="number" name="phonenumber" placeholder="Enter phone number e.g 07********" required="required">
    <input type="submit" name="change" value="Change Phone Number">
</form>
<?php echo $result ?>
</div>
<?php
include 'styles.html';
?>