<?php
include '../config.php';
$p=$_GET['p'];
$account=$_GET['account'];
if(isset($_POST['confirm'])){
    $phonenumber=$p;
    $code=addslashes($_POST['confirmationcode']);
    $enccode=md5($code);
    $codeqry=mysqli_query($config,"SELECT * FROM resetcode WHERE resetcode='$enccode' AND account='$account'");
    if(mysqli_num_rows($codeqry)>0){
        //update codebase
        mysqli_query($config,"UPDATE resetcode SET `status`='Used' WHERE account='$account'");
        //update account status
        mysqli_query($config,"UPDATE system_users SET `status`='Active' WHERE id='$account'");
        //find account information
        $accqry=mysqli_query($config,"SELECT * FROM system_users WHERE id='$account'");
        session_start();
        $accrow=mysqli_fetch_assoc($accqry);
        $password=$accrow['password'];
        $_SESSION['id']=$accrow['id'];
            $_SESSION['username']=$accrow['username'];
            $_SESSION['names']=$accrow['names'];
            $_SESSION['emailaddress']=$accrow['emailaddress'];
            $_SESSION['gender']=$accrow['gender'];
            $_SESSION['user']='Logged';
            setcookie('userdetail',$account.','.$password,time()+(10*365*60*60));
            header('location:home.php');
    }else{
        $result='<img src="../images/error.png" width="23" height="23" align="left"> Wrong code. If you did not receive the code please touch on Resend above.';
    }
}
?>
<div style="background-color: cyan;color:green;margin-top:30%;">
<h2>An sms has been sent to <?php echo $p ?></h2>
<h3>No sms? <a href="resendcode.php?p=<?php echo $p ?>">Resend</a> or <?php echo '<a href="changephone.php?account='.$account.'">Change Phone number</a></h3>' ?>
<form method="post">
    <input type="number" name="confirmationcode" placeholder="Enter confirmation code" required="required">
    <input type="submit" name="confirm" value="Confirm">
</form>
<?php echo $result ?>
</div>
<?php
include 'styles.html';
?>