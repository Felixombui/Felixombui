<?php
include '../config.php';
//new cURL function
function get_web_page( $myurl )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );

    $ch      = curl_init( $myurl );
    curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    return $header;
}
//end of function
if(isset($_POST['recover'])){
    //check if phonenumber is registered
    $phonenumber=addslashes($_POST['phonenumber']);
    $userqry=mysqli_query($config,"SELECT * FROM system_users WHERE phonenumber='$phonenumber'");
    if(mysqli_num_rows($userqry)>0){
        //create reset code
        $resetcode=rand(1000,9000);
        $userrow=mysqli_fetch_assoc($userqry);
        $account=$userrow['id'];
        $enccode=md5($resetcode);
        $time=date('h:m:i');
        $date=date('d-m-Y');
        if(mysqli_query($config,"INSERT INTO resetcode(account,resetcode,resettime,resetdate) VALUES('$account','$enccode','$time','$date')")){
            //create sms
            $message=urlencode('Dear customer. Please use '.$resetcode. ' as your password reset code. Thank you.');
            $url='http://macrasms.macrasystems.com/sendsms.php?senderid=PROPERTYLNS&phonenumber='.$phonenumber.'&message='.$message;
            get_web_page($url);
            header('location:entercode.php?account='.$account);
        }else{
            $result='<img src="../images/error.png" width="23" height="23" align="left"> Error! Unable to send code.';
        }
    }else{
        $result='<img src="../images/error.png" width="23" height="23" align="left"> The phone number you entered is not registered with us.';
    }
    
}
?>

<form method="post">
    
    <div class="loginform">
    <img src="../images/logo.png" width="180" height="180">
        <input type="text" name="phonenumber" placeholder="Enter your phone number here...">
        <input type="submit" class="loginbutton" name="recover" value="Recover">
        <p>
            <?php echo $result ?>
        </p>
    </div>

</form>

<?php
include 'styles.html';
?>