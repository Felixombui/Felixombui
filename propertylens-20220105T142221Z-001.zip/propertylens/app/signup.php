<?php
include '../config.php';
//new cURL function
function get_web_page( $myurl )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );

    $ch      = curl_init( $myurl );
    @curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    return $header;
}
//end of function
if(isset($_POST['signup'])){
$names=addslashes($_POST['names']);
$emailaddress=addslashes($_POST['emailaddress']);
$phonenumber=addslashes($_POST['phonenumber']);
$username=addslashes($_POST['username']);
$password=addslashes($_POST['password']);
$rpassword=addslashes($_POST['rpassword']);
$optin=$_POST['optin'];
if($password==$rpassword){
   //CHECK IF PHONE NUMBER EXISTS
   $usrqry=mysqli_query($config,"SELECT * FROM system_users WHERE phonenumber='$phonenumber'");
   if(mysqli_num_rows($usrqry)>0){
    $result='<img src="../images/error.png" width="23" height="23" align="left"> The phone number is already registered! <a href="login.php">Login</a>';
   }else{
       //check password strength
       $uppercase=preg_match('@[A-Z]@',$password);
       $lowercase=preg_match('@[a-z]@',$password);
       $number=preg_match('@[0-9]@',$password);
       $specialChars=preg_match('@[^\w]@', $password);
       if($uppercase || $lowercase || $number || $specialChars || strlen($password)>8){
        $encpass=md5($password);
       if(mysqli_query($config,"INSERT INTO system_users(names,emailaddress,phonenumber,marketingsms,username,`password`) VALUES('$names','$emailaddress','$phonenumber','$optin','$username','$encpass')")){
           //create confirmation code
           $confirmationcode=rand(1000,9999);
           $encCode=md5($confirmationcode);
           //find my new account id
           $accqry=mysqli_query($config,"SELECT * FROM system_users WHERE phonenumber='$phonenumber'");
           $accrow=mysqli_fetch_assoc($accqry);
           $accid=$accrow['id'];
           mysqli_query($config,"INSERT INTO resetcode(account,resetcode) VALUES('$accid','$encCode')");            
           //send welcome sms
           $message=urlencode('Dear '.$names.'. Welcome to Property Lens. The largest property market. Use '.$confirmationcode.' as your confirmation code.');
         $url='http://macrasms.macrasystems.com/sendsms.php?senderid=PROPERTYLNS&phonenumber='.$phonenumber.'&message='.$message;
        get_web_page($url);
        header('location:confirmationcode.php?p='.$phonenumber.'&account='.$accid);
       }
       }else{
        $result='<img src="../images/error.png" width="23" height="23" align="left"> Password should be at least 8 characters and include upper case, lower case, special characters and numbers.';
       }
       
   }
}else{
    $result='<img src="../images/error.png" width="23" height="23" align="left"> Your passwords do not match!';
}
}
?>
<script>
function viewPassword() {
  var x = document.getElementById("password");
  var y=document.getElementById("rpassword");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
  if (y.type === "password") {
    y.type = "text";
  } else {
    y.type = "password";
  }
}
</script> 
<form method="post">
    <div style="margin-top:20px">
    <input type="text" name="names" placeholder="Enter your full Name..." required="required">
    <input type="email" name="emailaddress" placeholder="Enter your emailaddress...">
    <input type="text" name="phonenumber" placeholder="Enter your phone number..." required="required">
    <input type="text" name="username" placeholder="Create your username..." required="required">
    <input type="password" name="password" id="password" placeholder="Create your password..." required="required">
    <input type="password" name="rpassword" id="rpassword" placeholder="Retype your password...">
    <div style="width: 100%;text-align:left"><input type="checkbox" onclick="viewPassword()" style="width:auto;margin-top:8px;margin-bottom:8px;"> Show Password</div>
    Do you want to be receiving our promotional sms?
    <select name="optin">
        <option selected>Yes</option>
        <option>No</option>
    </select><p>
    <img src="../images/info.png" width="23" height="23" align="left"> By clicking Sign Up, you have agreed to our <a href="privacy.html">privacy policy.</a></p>
    <input type="submit" name="signup" value="Sign Up" class="loginbutton">
    <?php echo $result ?>
    </div>
</form>
<?php
include 'styles.html';
?>