<?php
session_start();
include '../config.php';
$adsqry=mysqli_query($config,"SELECT * FROM adverts WHERE status='Approved' ORDER BY id DESC");
$catqry=mysqli_query($config,"SELECT * FROM categories");
if(empty($_SESSION['user'])){
    //header('location:login.php');
    $userdetail='<a href="login.php"> Login </a>';
}else{
    $userdetail='<a href="profile.php">'.$_SESSION['names'].'</a> [<a href="logout.php">Logout</a>]';
}
if(isset($_POST['search'])){
    $s=$_POST['search'];
    header('location:searchresults.php?s='.$s);
}

?>
    <div style="padding:10px; text-align:center;">
        <img src="../images/logo.png" width="150" height="150" align="center">
    </div>
    <div><img src="../images/user.png" width="23" height="23" align="left"><?php echo $userdetail ?></div>
    <div class="headers">
        
        <div>
            <form method="post">
                <input type="text" name="search" placeholder="Search Property here...">
            </form>
        </div>
    </div>
    <!--<div class="headings">
        Favourites
    </div>
    <div>
        This is where favorites appear...
    </div>-->
    <div class="headings">
        Categories
    </div>
    <div>
        <a href="searchresults.php?s=homes"><div class="categoryview">
            <img src="../images/house.jpg" width="100%" height="80%"><br>Homes
        </div></a>
        <a href="searchresults.php?s=land"><div class="categoryview">
            <img src="../images/plots.jpg" width="100%" height="80%"><br>Plots/Land
        </div></a>
        <a href="searchresults.php?s=vehicles"><div class="categoryview">
            <img src="../images/cars.jpeg" width="100%" height="80%"><br>Vehicles
        </div></a>
        
        <a href="searchresults.php?s=rentals"><div class="categoryview">
            <img src="../images/landlords.png" width="100%" height="80%"><br>Rentals
        </div></a>
        <a href="searchresults.php?s=house"><div class="categoryview">
            <img src="../images/house.jpg" width="100%" height="80%"><br>House
        </div></a>
        <a href="searchresults.php?s=school"><div class="categoryview">
            <img src="../images/school.jpg" width="100%" height="80%"><br>Schools
        </div></a>
        
    </div>
    <div class="headings">
        For Sale
    </div>
    <div>
        <?php
            while($adsrow=mysqli_fetch_assoc($adsqry)){
                $adid=$adsrow['id'];
                $title=$adsrow['title'];
                $description=$adsrow['description'];
                $unitcost=$adsrow['unitcost'];
                $aduser=$adsrow['userid'];
                //images
                $imgqry=mysqli_query($config,"SELECT * FROM images WHERE adno='$adid' ORDER BY id LIMIT 1");
                if(mysqli_num_rows($imgqry)>0){
                    $imgrow=mysqli_fetch_assoc($imgqry);
                    $img=$imgrow['imglocation'];
                }else{
                    $img='images/noimage.png';
                }
                
                //find seller phone
                $phnqry=mysqli_query($config,"SELECT * FROM system_users WHERE id='$aduser'");
                $phnrow=mysqli_fetch_assoc($phnqry);
                $mobile=$phnrow['phonenumber'];
                if(empty($_SESSION['id'])){
                    $redirectcall='login.php';
                }else{
                    $redirectcall='tel:'.$mobile;
                }
                
                echo '<table style="margin-top:10px;border-collapse:collapse;border:1px solid pink;">
                <tr class="adtitle"><th>'.$title.'</th></tr>
                <tr><td>
                <div style="float:left;width:20%;"><img src="../'.$img.'" width="120" height="100" align="left" style="float:left;"></div><div style="float:right;width:60%; margin-left:5px;">'
                
                .$description.'<p>Ksh.'.number_format($unitcost,2).'</p><p><a href="'.$redirectcall.'"></p>

                </div></td></tr>
                <tr><td>
                <button style="padding: 8px;width:48%;font-weight:bold;"><img src="../images/call.png" width="23" height="23" align="left" style="border-radius:50%;background-color:green;padding:3px;">Call Seller</button></a><a href="sendmessage.php?adid='.$adid.'"><button style="padding: 8px;width:48%;float:right;font-weight:bold;">Send Message <img src="../images/sms.png" width="23" height="23" align="right" style="border-radius:50%;background-color:white;padding:3px;"></button></a>
                </td></tr></table>';
                
            }
            echo '<div style="margin-bottom:100px;">&nbsp;</div>';
        ?>
    </div>
<div class="footer">
    <table><tr><td><a href="home.php"><img src="../images/home.png"><br>Home</a></td><td><a href="fav.php"><img src="../images/fav.png"><br>Favorites</a></td><td><a href="sell.php"><img src="../images/sellers.png"><br>Sell</a></td><td><a href="contacts.php"><img src="../images/emails.png"><br>Contacts</a></td><td><a href="profile.php"><img src="../images/user.png"><br>Profile</a></td></tr></table>
</div>
<?php
include 'styles.html';
?>>
