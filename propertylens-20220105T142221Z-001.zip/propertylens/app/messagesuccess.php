<?php
session_start();
include '../config.php';
$adid=$_GET['adid'];
if(empty($_SESSION['user'])){
    header('location:login.php');
    $userdetail='<a href="login.php"> Login </a>';
}else{
    $userdetail='<a href="profile.php">'.$_SESSION['names'].'</a> [<a href="logout.php">Logout</a>]';
    $usernames=$_SESSION['names'];
    $adqry=mysqli_query($config,"SELECT * FROM adverts WHERE id='$adid'");
    $adrow=mysqli_fetch_assoc($adqry);
    $adtitle=$adrow['title'];
    $description=$adrow['description'];
    $seller=$adrow['userid'];
}
//new cURL function
function get_web_page( $myurl )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );

    $ch      = curl_init( $myurl );
    @curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    return $header;
}
//end of function
set_time_limit(0);

?>
    <div style="padding:10px; text-align:center;">
        <img src="../images/logo.png" width="150" height="150" align="center">
    </div>
    <div><img src="../images/user.png" width="23" height="23" align="left"><?php echo $userdetail ?></div>
    <div class="headers">
        
        <div>
            Send Message
        </div>
    </div>
   <div style="margin-top: 20px;">
       <img src="../images/success.png" width="23" height="23" align="left"> Your message has been sent successfully.
   </div>
    
   <div class="footer">
    <table><tr><td><a href="home.php"><img src="../images/home.png"><br>Home</a></td><td><a href="fav.php"><img src="../images/fav.png"><br>Favorites</a></td><td><a href="sell.php"><img src="../images/sellers.png"><br>Sell</a></td><td><a href="contacts.php"><img src="../images/emails.png"><br>Contacts</a></td><td><a href="profile.php"><img src="../images/user.png"><br>Profile</a></td></tr></table>
</div>
<?php
include 'styles.html';
?>
