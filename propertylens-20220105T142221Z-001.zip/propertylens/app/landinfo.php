<?php
include '../config.php';
session_start();
$type = $_GET['type'];
if(empty($_SESSION['user'])){
    header('location:login.php');
    $userdetail='<a href="login.php"> Login </a>';
}else{
    $userdetail='<a href="profile.php">'.$_SESSION['names'].'</a> [<a href="logout.php">Logout</a>]';
    $usernames=$_SESSION['names'];
    $userid=$_SESSION['id'];
    $favqry=mysqli_query($config,"SELECT * FROM favs WHERE userid='$userid'");
}

$qry=mysqli_query($config,"SELECT * FROM adverts WHERE userid='$userid' ORDER BY id DESC LIMIT 1");
$adrow=mysqli_fetch_assoc($qry);
$adid=$adrow['id'];
$adtitle=$adrow['title'];
if(isset($_POST['submit'])){
    $adid=addslashes($id);
    $moreinfo='Size: '.$_POST['landsize'].',Plot No: '.$_POST['plotno'].',More Info: '.$_POST['moreinfo'];
    $description=addslashes($moreinfo);
    if(mysqli_query($config,"INSERT INTO moreinfo(adid,`description`) VALUES('$adid','$description')")){
        $info='<img src="../images/success.png" width="20" height="20" align="left"> Advert has been submitted successfully.';
    }else{
        $info='<img src="../images/error.png" width="20" height="20" align="left"> Advert submission failed.';
    }
}
?>
<p>
<style>
.headertable {
    border-collapse: collapse;
    border-bottom: 1px cyan solid;
    border-right: 1px cyan solid;
    border-left: 1px cyan solid;
    box-shadow: 1px 1px cyan;
}

</style>
<table  align = 'center' width = '80%' class = 'headertable'><tr class = 'profileheader'><td>
<div style="padding:10px; text-align:center;">
        <img src="../images/logo.png" width="150" height="150" align="center">
    </div>
    <div><img src="../images/user.png" width="23" height="23" align="left"><?php echo $userdetail ?></div>
    <div class="headers">
        
        <div>
            <img src="../images/sellers.png" width="23" height="23" align="left"> Create advert
        </div>
    </div>
</td></tr>
<tr><td>
<form method = 'post' enctype = 'multipart/form-data'>
<table style="background-color: cyan; width:100%"><tr><td>Advert No: <?php echo '<b>'.$adid.'</b>' ?> Advert Title: <?php echo '<b>'.$adtitle.'</b>' ?></td></tr></table>
<table width="50%" align="center">

    <tr><td>Size</td><td><input type="text" name="landsize"></td></tr>
    <tr><td>Plot Number</td><td><input type="text" name="plotno"></td></tr>
    <tr><td>More Info</td><td><textarea cols="18" rows="5" name="moreinfo" style="width: 100%;"></textarea></td></tr>
    <tr><td>&nbsp;</td><td><input type="submit" name="submit" value="Submit Info"></td></tr>
</table>
<table width="50%" align="center"><tr><td><?php echo $info ?></td></tr></table>

                        </form>
                        </td></tr>
                        </table>
                        </p>
                        <div class="footer">
    <table><tr><td><a href="home.php"><img src="../images/home.png"><br>Home</a></td><td><a href="fav.php"><img src="../images/fav.png"><br>Favorites</a></td><td><a href="sell.php"><img src="../images/sellers.png"><br>Sell</a></td><td><a href="contacts.php"><img src="../images/emails.png"><br>Contacts</a></td><td><a href="profile.php"><img src="../images/user.png"><br>Profile</a></td></tr></table>
</div>
<?php
include 'styles.html';
?>