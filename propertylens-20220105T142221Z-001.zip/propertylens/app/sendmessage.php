<?php
session_start();
include '../config.php';
$adid=$_GET['adid'];
if(empty($_SESSION['user'])){
    header('location:login.php');
    $userdetail='<a href="login.php"> Login </a>';
}else{
    $userdetail='<a href="profile.php">'.$_SESSION['names'].'</a> [<a href="logout.php">Logout</a>]';
    $usernames=$_SESSION['names'];
    $adqry=mysqli_query($config,"SELECT * FROM adverts WHERE id='$adid'");
    $adrow=mysqli_fetch_assoc($adqry);
    $adtitle=$adrow['title'];
    $description=$adrow['description'];
    $seller=$adrow['userid'];
}
//new cURL function
function get_web_page( $myurl )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );

    $ch      = curl_init( $myurl );
    @curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    return $header;
}
//end of function
set_time_limit(0);
if(isset($_POST['submit'])){
    $sender=$_SESSION['name'];
    $senderphone=$_SESSION['phonenumber'];
    $senderemail=$_SESSION['emailaddress'];
    $pagemessage=$_POST['message'];
    //send sms to the advert owner
    //find ad owner
    $ownerqry=mysqli_query($config,"SELECT * FROM system_users WHERE id='$seller'");
    $ownerrow=mysqli_fetch_assoc($ownerqry);
    $sellernames=$ownerrow['names'];
    $selleremail=$ownerrow['emailaddress'];
    $sellerphone=$ownerrow['phonenumber'];
    $message=urlencode('Dear '.$sellernames.', You have a contact from Minanda. Please check your app for details.');
    $url='http://macrasms.macrasystems.com/sendsms.php?senderid=PROPERTYLNS&phonenumber='.$sellerphone.'&message='.$message;
    get_web_page($url);
    //send email to the seller
    $emailbody=urlencode('Dear '.$sellernames.', '.$usernames.' is interested in your advert '.$adtitle.'. Phone number:'.$senderphone.'\n Email address:'.$senderemail.'\n Their message is: '.$pagemessage);
    $notification=urldecode($emailbody);
    $maillink='https://propertylens.co.ke/mailer.php?emailaddress='.$emailaddress.'&mailNames='.$fullnames.'&subject=Contact+From+'.$userdetail.'&mailMessage='.$pagemessage;
    get_web_page($maillink);
    //add to notifications
    mysqli_query($config,"INSERT INTO notifications(userid,`notification`) VALUES('$seller','$notification')");
    header('location:messagesuccess.php');
}
?>
    <div style="padding:10px; text-align:center;">
        <img src="../images/logo.png" width="150" height="150" align="center">
    </div>
    <div><img src="../images/user.png" width="23" height="23" align="left"><?php echo $userdetail ?></div>
    <div class="headers">
        
        <div>
            <img src="../images/sms.png" width="23" height="23" align="left"> Send Message
        </div>
    </div>
   <div style="margin-top: 20px;">
       <form action="" method="POST">
           <textarea name="message" id="message" cols="30" rows="10" style="width: 100%;">Is this still available?
           </textarea>
           <input type="submit" name="submit" value="Send Message">
       </form>
   </div>
    
   <div class="footer">
    <table><tr><td><a href="home.php"><img src="../images/home.png"><br>Home</a></td><td><a href="fav.php"><img src="../images/fav.png"><br>Favorites</a></td><td><a href="sell.php"><img src="../images/sellers.png"><br>Sell</a></td><td><a href="contacts.php"><img src="../images/emails.png"><br>Contacts</a></td><td><a href="profile.php"><img src="../images/user.png"><br>Profile</a></td></tr></table>
</div>
<?php
include 'styles.html';
?>
