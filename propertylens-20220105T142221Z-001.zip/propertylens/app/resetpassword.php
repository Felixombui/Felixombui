<?php
include '../config.php';
$account=$_GET['account'];
//new cURL function
function get_web_page( $myurl )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );

    $ch      = curl_init( $myurl );
    curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    return $header;
}
//end of function
if(isset($_POST['recover'])){
    $password=addslashes($_POST['password']);
    $rpassword=addslashes($_POST['rpassword']);
    if($password==$rpassword){
        $newpassword=md5($password);
        if(mysqli_query($config,"UPDATE system_users SET `password`='$newpassword' WHERE id='$account'")){
            $result='<img src="../images/success.png" width="23" height="23" align="left"> Password changed successfully. <a href="login.php">Login now </a>';
        }
    }else{
        $result='<img src="../images/error.png" width="23" height="23" align="left"> The passwords you entered do not match!';
    }
}
?>

<form method="post">
    
    <div class="loginform">
    <img src="../images/logo.png" width="180" height="180"><p>
    <b>Enter the code you have received on sms</b>
        <input type="password" name="password" placeholder="Create New Password...">
        <input type="password" name="rpassword" placeholder="Create New Password...">
        <input type="submit" class="loginbutton" name="recover" value="Reset Password">
        <p>
            <?php echo $result ?>
        </p>
        
    </div>

</form>

<?php
include 'styles.html';
?>