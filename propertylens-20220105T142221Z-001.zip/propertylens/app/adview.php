<?php
session_start();
include '../config.php';
$adid=$_GET['adid'];
$userid=$_SESSION['id'];
if(empty($_SESSION['user'])){
    //header('location:login.php');
}
$adqry=mysqli_query($config,"SELECT * FROM adverts WHERE id='$adid'");
$adrow=mysqli_fetch_assoc($adqry);
$title=$adrow['title'];
$description=$adrow['description'];
$cost=$adrow['unitcost'];
$category=$adrow['propertytype'];
//update visited favs
mysqli_query($config,"INSERT INTO favs(userid,category,adid) VALUES('$userid','$category','$adid')");
;?>

    <div style="padding:10px; text-align:center;">
        <img src="../images/logo.png" width="150" height="150" align="center">
    </div>
    <div class="headers">
        
        <div>
            <?php echo $title ?>
        </div>
    </div>
    
    <?php
    //fetch all images associated with ad
    $imgqry=mysqli_query($config,"SELECT * FROM images WHERE adno='$adid'");
    while($imgrow=mysqli_fetch_assoc($imgqry)){
        $imgid=$imgrow['id'];
        $img=$imgrow['imglocation'];
        echo '<div><img src="../'.$img.'" width="100%" height="50%"></div>';
    }
        echo '<div style="color:grey;">'.$description.'</div>';
        echo '<div><b>Ksh.'.number_format($cost,2).'</b></div>';
        echo '<div><button style="background-color:blue;color:white;padding:10px;width:48%;"><img src="../images/call.png" width="23" height="23" align="left"><b>Call Seller</b></button><button style="background-color:blue;color:white;padding:10px;width:48%;float:right;"><img src="../images/sms.png" width="23" height="23" align="left"><b>Message Seller</b></button></div>';
        //update visited notifications
        mysqli_query($config,"INSERT INTO notifications")
    ?>

    </div>
        <?php
            echo '<div style="margin-bottom:100px;">&nbsp;</div>';
        ?>
    </div>
<div class="footer">
    <table><tr><td><a href="home.php"><img src="../images/home.png"><br>Home</a></td><td><a href="fav.php"><img src="../images/fav.png"><br>Favorites</a></td><td><a href="sell.php"><img src="../images/sellers.png"><br>Sell</a></td><td><a href="contacts.php"><img src="../images/emails.png"><br>Contacts</a></td><td><a href="profile.php"><img src="../images/user.png"><br>Profile</a></td></tr></table>
</div>
<?php
include 'styles.html';
?>
