<?php
$phonenumber=$_GET['phonenumber'];
$message=$_GET['message'];
$message(urlencode($message));
$url='http://macrasystems.com/sms/sendsms.php?senderid=PROPERTYLNS&phonenumber='.$phonenumber.'&message='.$message;
?>