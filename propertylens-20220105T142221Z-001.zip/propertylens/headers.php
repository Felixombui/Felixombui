<?php
session_start();
include 'config.php';

if ( empty( $_SESSION['fullnames'] ) ) {
    $headerlinks = 'Already a member? <a href="signin.php">Sign in</a> | <a href="signup.php">Create a free account</a>';
} else {
    $username = $_SESSION['username'];
    $chatsqry = mysqli_query( $config, "SELECT * FROM inbox WHERE `to`='$username' AND status='Unread'" );
    $chats = mysqli_num_rows( $chatsqry );
    $headerlinks = 'Welcome <a href="profile.php">'.$_SESSION['fullnames'].'</a> [<a href="signout.php">Sign out</a>] | <a href="newad.php">Create Ad</a> | <a href="myadverts.php">My Ads</a> | <a href="inbox.php">Inbox('.$chats.')</a>';
}

if ( isset( $_POST['find'] ) ) {
    $searchtext = addslashes( $_POST['search'] );
    $searchtext = urlencode( $searchtext );
    header( 'location:searchresults.php?key='.$searchtext );
}
echo '<title>Property Lens</title>';
echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
echo '<div class = "top"><img src="images/logo.png" width="210" height="150"></div>
<div align="right">
<div class = "mainmenu">
<table><tr><td><a href="index.php">Home</a> |</td><td><a href="aboutus.php">About</a> |</td><td><a href="contactus.php">Contact us</a></td></tr></table>
</div>
'.$headerlinks.'
</div>
<div class = "headers">
    <table class="top"><tr><td>Search Property<br><form method="post">
    <input type="text" class="search" name="search" placeholder="Location e.g Kiserian,property e.g land..."><input type="submit" class="searchbutton" name="find" value="Search"><br>
    <div style="font-size: 14;" ><input type="checkbox" name="type" value="1">Land &nbsp;<input type="checkbox" name="type" value=1>Houses</div>
</form></td></tr></table>
</div>';

?>

