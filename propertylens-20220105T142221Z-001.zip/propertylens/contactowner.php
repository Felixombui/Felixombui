<?php
session_start();
if ( empty( $_SESSION['fullnames'] ) ) {
    header( 'location:signin.php' );
}

include 'headers.php';
//include 'sendsms.php';
$userid = $_GET['userid'];
$mynumber = $_SESSION['phonenumber'];
$id = $_GET['id'];
$enquiries = mysqli_query( $config, 'SELECT * FROM enquiries ORDER BY id DESC' );
$adqry = mysqli_query( $config, "SELECT * FROM adverts WHERE id='$id'" );
$adrow = mysqli_fetch_assoc( $adqry );
$propertytype = $adrow['propertytype'];
$location = $adrow['county'].' ,'.$adrow['locality'];
$qry = mysqli_query( $config, "SELECT * FROM system_users WHERE id='$userid'" );
$row = mysqli_fetch_assoc( $qry );
$names = $row['names'];
$phonenumber = $row['phonenumber'];
$emailaddress = $row['emailaddress'];

if ( isset( $_POST['send'] ) ) {
    $chars = strlen( $phonenumber );
    if ( $chars<11 ) {
        $newphone = ltrim( $phonenumber, '0' );
        $phonenumber = '254'.$newphone;
    }
    $message = addslashes( $_POST['message'] );
    $message = urlencode( $message );
    $url = 'http://sms.macrasystems.com/sendsms/index.php?username=Mankan&senderid=SMARTLINK&phonenumber='.$phonenumber.'&message='.$message;
    file_get_contents( $url );
    //sendSMS( $phonenumber, $message );
    header( 'location:index.php' );
    echo 'Message sent to '.$phonenumber ;
    $_POST['message'] = '';
    $_POST['emailaddress'] = '';
    $_POST['phonenumber'] = '';
}
?>
<p>
<table width = '80%' align = 'center'>
<tr><td>
<div style = 'float: left; width:79%'>
<?php
echo 'Names: '.$names.'<br>';
echo 'Email: '.$emailaddress.'<br>';
echo 'Phone: '.$phonenumber;
?>
<form method = 'post'>
<table>
<tr><td>Email Address:</td><td><input type = 'email' name = 'emailaddress' value = "<?php echo $emailaddress ?>" size = '40' readonly></td></tr>
<tr><td>Phone Number:</td><td><input type = 'tel' name = 'phonenumber' value = "<?php echo $phonenumber ?>" size = '40' readonly></td></tr>
<tr><td>Message:</td><td><textarea name = 'message' cols = '34' rows = '4' readonly>Hi. I am interested in your <?php echo $propertytype ?> at <?php echo $location ?>. Please contact me on <?php echo $mynumber ?>. <?php echo $_SESSION['fullnames'] ?></textarea></td></tr>
<tr><td></td><td align = 'right'><input type = 'submit' name = 'send' value = 'Send Message' class = 'searchbutton'></td></tr>
</table>
</form>
</div>
<div style = 'float: right;
width:20%'>
<?php
while( $enqrow = mysqli_fetch_assoc( $enquiries ) ) {
    $enqid = $enqrow['id'];
    $comms = mysqli_query( $config, "SELECT id FROM enq_comments WHERE anqid='$enqid'" );
    $comments = mysqli_num_rows( $comms );
    $usernames = $enqrow['usernames'];
    $query = $enqrow['enquiry'];
    $enquirydate = $enqrow['enquirydate'];
    echo '<a href = "enquiries.php?eid = '.$enqid.'">';
    echo "<table width = '100%' style = 'border:1px solid cyan' class = 'enquiry'><tr><td>
<img src = 'images/user.png' width = '30' height = '30' align = 'left'>";
    echo '<b>'.$usernames.'</b><br><i>'.$enquirydate.'</i><br>'.$query."
<table style = 'color:blue;
font-size:11;
'><tr><td>Comments: ".$comments."</td></tr></table>
</td></tr></table></a><p>";
}
?>
</div>
</td></tr>
</table>
</p>
<style>
<?php echo include 'styles.css' ?>
</style>
<div style = 'float:left;
width:79%;
'>

</div>
<div style = 'float: right;
width:20%'>

</div>