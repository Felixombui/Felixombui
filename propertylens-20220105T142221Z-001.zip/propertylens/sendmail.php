<?php
require 'PHPMailer-master/src/PHPMailer.php';
$mail= new PHPMailer;
$mail->setFrom('raphmachoka@gmail.com','Raphael Machoka');
$mail->addAddress('info@macrasystems.com','Info');
$mail->Subject='Welcome';
$mail->Body='Hi. Sent from phpmailer';
if(!$mail->send()){
    echo 'Message was not sent.';
    echo 'Mmailer error: '.$mail->ErrorInfo;
}else{
    echo 'Mesage has been sent.';
}
?>